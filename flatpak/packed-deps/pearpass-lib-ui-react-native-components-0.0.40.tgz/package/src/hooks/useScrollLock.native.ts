export const useScrollLock = () => {
    return;
};
