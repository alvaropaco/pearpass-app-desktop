// This file is auto-generated. Do not edit it.
import * as React from "react";
import type { SVGProps } from "react";
const SvgErrorFilled = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" fill="none" viewBox="0 0 24 24" {...props}>
    <path
      fill="currentColor"
      d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m1 15h-2v-2h2zm0-4h-2V7h2z"
    />
  </svg>
);
export default SvgErrorFilled;
