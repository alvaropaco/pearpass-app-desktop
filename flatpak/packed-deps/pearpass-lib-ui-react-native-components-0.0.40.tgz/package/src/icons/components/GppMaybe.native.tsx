// This file is auto-generated. Do not edit it.
import * as React from "react";
import Svg, { Path } from "react-native-svg";
import type { SvgProps } from "react-native-svg";
const SvgGppMaybe = (props: SvgProps) => (
  <Svg width={24} height={24} fill="none" viewBox="1 0.5 10 11" {...props}>
    <Path
      fill="currentColor"
      d="M6 1 2 2.5v3.045C2 8.07 3.705 10.425 6 11c2.295-.575 4-2.93 4-5.455V2.5zm3 4.545c0 2-1.275 3.85-3 4.415-1.725-.565-3-2.41-3-4.415v-2.35L6 2.07l3 1.125z"
    />
    <Path fill="currentColor" d="M6.5 7h-1v1h1zM6.5 3.5h-1V6h1z" />
  </Svg>
);
export default SvgGppMaybe;
