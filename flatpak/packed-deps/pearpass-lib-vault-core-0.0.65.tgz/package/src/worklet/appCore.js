/** @typedef {import('bare')} */ /* global BareKit */
import RPC from 'bare-rpc'
import FramedStream from 'framed-stream'

import { API, API_BY_VALUE } from './api'
import {
  activeVaultAdd,
  activeVaultGet,
  activeVaultGetFile,
  activeVaultList,
  activeVaultRemoveFile,
  closeActiveVaultInstance,
  closeAllInstances,
  closeVaultsInstance,
  createInvite,
  deleteInvite,
  encryptionAdd,
  encryptionClose,
  encryptionGet,
  encryptionInit,
  getIsActiveVaultInitialized,
  getIsEncryptionInitialized,
  getIsVaultsInitialized,
  initActiveVaultInstance,
  initListener,
  resumeAllInstances,
  suspendAllInstances,
  pairActiveVault,
  cancelPairActiveVault,
  getBlindMirrors,
  addBlindMirrors,
  removeBlindMirror,
  addDefaultBlindMirrors,
  removeAllBlindMirrors,
  restartActiveVault,
  setStoragePath,
  vaultRemove,
  vaultsAdd,
  vaultsGet,
  masterVaultInit,
  vaultsList,
  rateLimitRecordFailure,
  getRateLimitStatus,
  resetRateLimit,
  setCoreStoreOptions,
  setJobStoragePath,
  readAndDecryptJobFile,
  writeAndEncryptJobFile,
  generateOtpCodesByIds,
  generateHotpNext,
  addOtpToRecord,
  removeOtpFromRecord
} from './appDeps'
import { decryptVaultKey } from './decryptVaultKey'
import { encryptVaultKeyWithHashedPassword } from './encryptVaultKeyWithHashedPassword'
import { encryptVaultWithKey } from './encryptVaultWithKey'
import { encryptExportData, decryptExportData } from './exportDataEncryption'
import { faviconManager } from './faviconManager'
import { getDecryptionKey } from './getDecryptionKey'
import { hashPassword } from './hashPassword'
import { masterPasswordManager } from './masterPasswordManager'
import { withMirrorValidation } from '../middleware/validateMirrorKeyViaDHT.js'
import { destroySharedDHT } from './utils/dht'
import { receiveFileStream } from '../utils/recieveFileStream.js'
import { sendFileStream } from '../utils/sendFileStream.js'
import { isPearWorker } from './utils/isPearWorker'
import { parseRequestData } from './utils/parseRequestData'
import { workletLogger } from './utils/workletLogger'
import { validateInviteCode } from '../utils/validateInviteCode.js'

let rpc = null

export const handleRpcCommand = async (req) => {
  const commandName = API_BY_VALUE[req.command]

  const requestData = parseRequestData(req.data)

  workletLogger.log(`Received command: ${commandName}`, requestData ?? '')

  switch (req.command) {
    case API.STORAGE_PATH_SET:
      try {
        void setStoragePath(requestData?.path)

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error setting storage path: ${error}`
          })
        )
      }

      break

    case API.SET_CORE_STORE_OPTIONS:
      try {
        workletLogger.log('Setting core store options:', requestData)
        setCoreStoreOptions(requestData?.coreStoreOptions)

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error setting core store options: ${error}`
          })
        )
      }
      break

    case API.FETCH_FAVICON:
      try {
        const faviconBase64 = await faviconManager.fetchFavicon(
          requestData?.url
        )

        if (!faviconBase64) {
          throw new Error('Favicon not found')
        }

        req.reply(
          JSON.stringify({
            success: true,
            data: {
              url: requestData?.url,
              favicon: faviconBase64
            }
          })
        )
      } catch (err) {
        workletLogger.error('Error fetching favicon:', err)
        req.reply(
          JSON.stringify({
            success: false,
            error: err.toString()
          })
        )
      }

      break

    case API.MASTER_VAULT_INIT:
      try {
        if (!requestData.encryptionKey) {
          throw new Error('Password is required')
        }

        const res = await masterVaultInit({
          encryptionKey: requestData.encryptionKey,
          hashedPassword: requestData.hashedPassword
        })

        req.reply(JSON.stringify({ success: true, res }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error initializing vaults: ${error}`
          })
        )
      }

      break

    case API.MASTER_VAULT_GET_STATUS:
      req.reply(JSON.stringify({ data: { status: getIsVaultsInitialized() } }))

      break

    case API.MASTER_VAULT_GET:
      try {
        const res = await vaultsGet(requestData?.key)

        req.reply(JSON.stringify({ data: res }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error getting records from active vault: ${error}`
          })
        )
      }

      break

    case API.MASTER_VAULT_CLOSE:
      try {
        await closeVaultsInstance()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error closing vaults: ${error}`
          })
        )
      }

      break

    case API.MASTER_VAULT_ADD:
      try {
        await vaultsAdd(requestData?.key, requestData?.data)

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error adding vault: ${error}`
          })
        )
      }

      break

    case API.ACTIVE_VAULT_FILE_ADD:
      try {
        const stream = req.createRequestStream()

        const { buffer, metaData } = await receiveFileStream(stream)
        const { key, name } = metaData ?? {}
        await activeVaultAdd(key, {}, buffer, name)

        workletLogger.log({
          stream: `Received stream data of size: ${buffer.length}`,
          data: JSON.stringify(metaData)
        })

        req.reply(JSON.stringify({ success: true, metaData }))
      } catch (error) {
        workletLogger.error('Error adding file to active vault:', error)
        req.reply(
          JSON.stringify({
            error: `Could not add ${error.details?.fileName ?? 'file'} to the active vault: ${error.message}`
          })
        )
      }

      break

    case API.ACTIVE_VAULT_FILE_GET:
      try {
        const file = await activeVaultGetFile(requestData?.key)

        const stream = req.createResponseStream()

        sendFileStream({
          stream,
          buffer: file,
          metaData: { key: requestData?.key }
        })
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error getting file from active vault: ${error}`
          })
        )
      }

      break

    case API.ACTIVE_VAULT_FILE_REMOVE:
      try {
        await activeVaultRemoveFile(requestData?.key)

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error removing file from active vault: ${error}`
          })
        )
      }

      break

    case API.MASTER_VAULT_LIST:
      try {
        const vaults = await vaultsList(requestData?.filterKey)

        req.reply(JSON.stringify({ data: vaults }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error listing vaults: ${error}`
          })
        )
      }

      break

    case API.ACTIVE_VAULT_INIT:
      try {
        await initActiveVaultInstance({
          id: requestData?.id,
          encryptionKey: requestData?.encryptionKey
        })

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error initializing active vault: ${error}`
          })
        )
      }

      break

    case API.ACTIVE_VAULT_GET_STATUS:
      req.reply(
        JSON.stringify({ data: { status: getIsActiveVaultInitialized() } })
      )

      break

    case API.ACTIVE_VAULT_CLOSE:
      try {
        await closeActiveVaultInstance()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error closing active vault: ${error}`
          })
        )
      }

      break

    case API.ACTIVE_VAULT_ADD:
      try {
        await activeVaultAdd(requestData?.key, requestData?.data)

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error adding record to active vault: ${error}`
          })
        )
      }

      break

    case API.ACTIVE_VAULT_REMOVE:
      try {
        await vaultRemove(requestData?.key)

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error removing record from active vault: ${error}`
          })
        )
      }

      break

    case API.ACTIVE_VAULT_LIST:
      try {
        const listResults = await activeVaultList(requestData?.filterKey)

        req.reply(JSON.stringify({ data: listResults }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error listing records from active vault: ${error}`
          })
        )
      }

      break

    case API.ACTIVE_VAULT_GET:
      try {
        const record = await activeVaultGet(requestData?.key)

        req.reply(JSON.stringify({ data: record }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error getting records from active vault: ${error}`
          })
        )
      }

      break

    case API.ACTIVE_VAULT_CREATE_INVITE:
      try {
        const invite = await createInvite()

        req.reply(JSON.stringify({ data: invite }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error creating invite from active vault: ${error}`
          })
        )
      }

      break

    case API.ACTIVE_VAULT_DELETE_INVITE:
      try {
        await deleteInvite()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error deleting invite from active vault: ${error}`
          })
        )
      }

      break

    case API.PAIR_ACTIVE_VAULT:
      try {
        workletLogger.log('Validating invite code:', requestData.inviteCode)
        validateInviteCode(requestData.inviteCode)

        workletLogger.log('Pairing with invite code:', requestData.inviteCode)

        const { vaultId, encryptionKey } = await pairActiveVault(
          requestData.inviteCode
        )

        req.reply(JSON.stringify({ data: { vaultId, encryptionKey } }))

        workletLogger.log(
          'Pairing successful with invite code:',
          requestData.inviteCode,
          'Vault ID:',
          vaultId,
          'Encryption Key:',
          encryptionKey
        )
      } catch (error) {
        workletLogger.error('Error pairing with invite code:', error)

        req.reply(
          JSON.stringify({
            error: `Error pairing with invite code: ${error}`
          })
        )
      }

      break

    case API.CANCEL_PAIR_ACTIVE_VAULT:
      try {
        workletLogger.log('Canceling pairing with active vault')

        await cancelPairActiveVault()

        req.reply(JSON.stringify({ success: true }))

        workletLogger.log('Pairing with active vault canceled successfully')
      } catch (error) {
        workletLogger.error('Error canceling pairing with active vault:', error)

        req.reply(
          JSON.stringify({
            error: `Error canceling pairing with active vault: ${error}`
          })
        )
      }

      break

    case API.MASTER_PASSWORD_STATUS:
      const result = await getRateLimitStatus()

      req.reply(JSON.stringify({ data: result }))

      break

    case API.RECORD_FAILED_MASTER_PASSWORD:
      try {
        await rateLimitRecordFailure()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error recording failed master pass: ${error}`
          })
        )
      }

      break

    case API.RESET_FAILED_ATTEMPTS:
      try {
        await resetRateLimit()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error resetting failed attempts: ${error}`
          })
        )
      }

      break

    case API.MASTER_PASSWORD_CREATE:
      try {
        const data = await masterPasswordManager.createMasterPassword({
          passwordBase64: requestData.password
        })

        req.reply(JSON.stringify({ data }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error creating master password: ${error}`
          })
        )
      }

      break

    case API.MASTER_PASSWORD_INIT_WITH_PASSWORD:
      try {
        const data = await masterPasswordManager.initWithPassword({
          passwordBase64: requestData.password
        })

        req.reply(JSON.stringify({ data }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error initializing with password: ${error}`
          })
        )
      }

      break

    case API.MASTER_PASSWORD_UPDATE:
      try {
        const data = await masterPasswordManager.updateMasterPassword({
          newPassword: requestData.newPassword,
          currentPassword: requestData.currentPassword
        })

        req.reply(JSON.stringify({ data }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error updating master password: ${error}`
          })
        )
      }

      break

    case API.MASTER_PASSWORD_INIT_WITH_CREDENTIALS:
      try {
        const data = await masterPasswordManager.initWithCredentials({
          ciphertext: requestData.ciphertext,
          nonce: requestData.nonce,
          hashedPassword: requestData.hashedPassword
        })

        req.reply(JSON.stringify({ data }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error initializing with credentials: ${error}`
          })
        )
      }

      break

    case API.INIT_LISTENER:
      try {
        if (!getIsActiveVaultInitialized()) {
          throw new Error('Active vault not initialized')
        }

        const vaultId = requestData.vaultId

        await initListener({
          vaultId: vaultId,
          onUpdate: () => {
            const req = rpc.request(API.ON_UPDATE)

            req.send()
          }
        })

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error initializing listener: ${error}`
          })
        )
      }

      break

    case API.ENCRYPTION_INIT:
      try {
        await encryptionInit()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error initializing encryption: ${error}`
          })
        )
      }

      break

    case API.ENCRYPTION_GET_STATUS:
      req.reply(
        JSON.stringify({ data: { status: getIsEncryptionInitialized() } })
      )

      break

    case API.ENCRYPTION_GET:
      try {
        const res = await encryptionGet(requestData?.key)

        req.reply(JSON.stringify({ data: res }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error getting encryption data: ${error}`
          })
        )
      }

      break

    case API.ENCRYPTION_ADD:
      try {
        await encryptionAdd(requestData?.key, requestData?.data)

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error adding encryption data: ${error}`
          })
        )
      }

      break

    case API.ENCRYPTION_HASH_PASSWORD:
      try {
        const res = hashPassword(requestData.password)

        req.reply(JSON.stringify({ data: res }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error hashPassword: ${error}`
          })
        )
      }

      break

    case API.ENCRYPTION_ENCRYPT_VAULT_KEY_WITH_HASHED_PASSWORD:
      try {
        const res = encryptVaultKeyWithHashedPassword(
          requestData.hashedPassword
        )

        req.reply(JSON.stringify({ data: res }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error encryptVaultKeyWithHashedPassword: ${error}`
          })
        )
      }

      break

    case API.ENCRYPTION_ENCRYPT_VAULT_WITH_KEY:
      try {
        const res = encryptVaultWithKey(
          requestData.hashedPassword,
          requestData.key
        )

        req.reply(JSON.stringify({ data: res }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error encryptVaultWithKey: ${error}`
          })
        )
      }

      break

    case API.ENCRYPTION_GET_DECRYPTION_KEY:
      try {
        const { salt, password } = requestData

        const hashedPassword = getDecryptionKey({
          password,
          salt
        })

        req.reply(JSON.stringify({ data: hashedPassword }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error getDecryptionKey: ${error}`
          })
        )
      }

      break

    case API.ENCRYPTION_DECRYPT_VAULT_KEY:
      try {
        const { ciphertext, nonce, hashedPassword } = requestData

        const res = decryptVaultKey({
          ciphertext,
          nonce,
          hashedPassword
        })

        req.reply(JSON.stringify({ data: res }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error decrypting vault key: ${error}`
          })
        )
      }

      break

    case API.ENCRYPTION_ENCRYPT_EXPORT_DATA:
      try {
        const { data, password } = requestData

        const encryptedData = encryptExportData(data, password)

        req.reply(JSON.stringify({ data: encryptedData }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error encrypting export data: ${error}`
          })
        )
      }

      break

    case API.ENCRYPTION_DECRYPT_EXPORT_DATA:
      try {
        const { encryptedData, password } = requestData

        const decryptedData = decryptExportData(encryptedData, password)

        req.reply(JSON.stringify({ data: decryptedData }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error decrypting export data: ${error.message || error}`
          })
        )
      }

      break

    case API.ENCRYPTION_CLOSE:
      try {
        await encryptionClose()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error closing encryption: ${error}`
          })
        )
      }

      break

    case API.CLOSE_ALL_INSTANCES:
      try {
        await closeAllInstances()
        await destroySharedDHT()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error closing encryption: ${error}`
          })
        )
      }

      break

    case API.BLIND_MIRRORS_GET:
      try {
        const mirrors = await getBlindMirrors()

        req.reply(JSON.stringify({ data: mirrors }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error getting blind mirrors: ${error}`
          })
        )
      }

      break

    case API.BLIND_MIRRORS_ADD:
      try {
        const safeAdd = withMirrorValidation(addBlindMirrors)
        await safeAdd(requestData?.blindMirrors || [])
        await restartActiveVault()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error adding blind mirrors: ${error}`
          })
        )
      }

      break

    case API.BLIND_MIRROR_REMOVE:
      try {
        await removeBlindMirror(requestData?.key)
        await restartActiveVault()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error removing blind mirrors: ${error}`
          })
        )
      }

      break

    case API.BLIND_MIRRORS_ADD_DEFAULTS:
      try {
        await addDefaultBlindMirrors()
        await restartActiveVault()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error adding default blind mirrors: ${error}`
          })
        )
      }

      break

    case API.BLIND_MIRRORS_REMOVE_ALL:
      try {
        await removeAllBlindMirrors()
        await restartActiveVault()

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error removing all blind mirrors: ${error}`
          })
        )
      }

      break

    case API.SET_JOB_STORAGE_PATH:
      try {
        setJobStoragePath(requestData?.path)

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error setting job storage path: ${error}`
          })
        )
      }

      break

    case API.READ_JOB_QUEUE:
      try {
        const jobs = await readAndDecryptJobFile()

        req.reply(JSON.stringify({ data: jobs }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error reading job queue: ${error}`
          })
        )
      }

      break

    case API.WRITE_JOB_QUEUE:
      try {
        await writeAndEncryptJobFile(requestData?.jobs)

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error writing job queue: ${error}`
          })
        )
      }

      break

    case API.GENERATE_OTP_CODES_BY_IDS:
      try {
        const otpCodes = await generateOtpCodesByIds(requestData?.recordIds)

        req.reply(JSON.stringify({ data: otpCodes }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error generating OTP codes: ${error}`
          })
        )
      }

      break

    case API.GENERATE_HOTP_NEXT:
      try {
        const hotpResult = await generateHotpNext(requestData?.recordId)

        req.reply(JSON.stringify({ data: hotpResult }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error generating next HOTP code: ${error}`
          })
        )
      }

      break

    case API.ADD_OTP_TO_RECORD:
      try {
        await addOtpToRecord(requestData?.recordId, requestData?.otpInput)

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error adding OTP to record: ${error}`
          })
        )
      }

      break

    case API.REMOVE_OTP_FROM_RECORD:
      try {
        await removeOtpFromRecord(requestData?.recordId)

        req.reply(JSON.stringify({ success: true }))
      } catch (error) {
        req.reply(
          JSON.stringify({
            error: `Error removing OTP from record: ${error}`
          })
        )
      }

      break

    default:
      req.reply(
        JSON.stringify({
          error: `Unknown command: ${req.command}`
        })
      )
      return
  }
}

export const setupIPC = () => {
  const ipc = isPearWorker()
    ? Pear.worker.pipe()
    : // New bare-sidecar exposes IPC on Bare.IPC.
      // eslint-disable-next-line no-undef
      (typeof Bare !== 'undefined' && Bare?.IPC) ||
      // Older pear-sidecar builds exposed IPC via BareKit.IPC.
      (typeof BareKit !== 'undefined' && BareKit?.IPC) ||
      // Legacy sidecar runtime set global symbol.
      global[Symbol.for('bare.sidecar.ipc')]

  if (!ipc) {
    throw new Error(
      'Worklet IPC not available (not Pear worker and no bare.sidecar.ipc)'
    )
  }

  // Bare-sidecar runtime sets ipc.unref(), so the process would exit. Keep the process alive.
  if (typeof ipc.ref === 'function') {
    ipc.ref()
  }

  ipc.on('close', async () => {
    await destroySharedDHT()
    // eslint-disable-next-line no-undef
    Bare.exit(0)
  })

  ipc.on('end', async () => {
    await destroySharedDHT()
    // eslint-disable-next-line no-undef
    Bare.exit(0)
  })

  // Suspend/resume Autopass instances via Bare lifecycle events.
  // bare-kit calls NativeBareKit.suspend() on AppState 'background',
  // which fires Bare 'suspend' inside the worklet before pausing the
  // event loop.
  // eslint-disable-next-line no-undef
  if (typeof Bare !== 'undefined') {
    workletLogger.log('Bare lifecycle events detected')
    // eslint-disable-next-line no-undef
    Bare.on('suspend', () => {
      workletLogger.log('Bare suspend event detected')
      suspendAllInstances()
        .catch(() => workletLogger.error('Error suspending instances'))
        .then(() => workletLogger.log('Instances suspended successfully'))
    })
    // eslint-disable-next-line no-undef
    Bare.on('resume', () => {
      workletLogger.log('Bare resume event detected')
      resumeAllInstances()
        .catch(() => workletLogger.error('Error resuming instances'))
        .then(() => workletLogger.log('Instances resumed successfully'))
    })
  }

  return ipc
}

export const createRPC = (ipc) => {
  rpc = new RPC(new FramedStream(ipc), (req) => {
    try {
      return handleRpcCommand(req)
    } catch (error) {
      req.reply(
        JSON.stringify({
          error: `Unexpected error: ${error}`
        })
      )
    }
  })
  return rpc
}
