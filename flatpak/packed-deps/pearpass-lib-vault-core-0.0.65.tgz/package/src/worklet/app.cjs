var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/utils/workletLogger.js
var noop, WorkletLogger, workletLogger;
var init_workletLogger = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/utils/workletLogger.js"() {
    noop = () => {
    };
    WorkletLogger = class {
      constructor({ debugMode = false } = {}) {
        this.output = console.log;
        this.debugMode = debugMode;
      }
      setLogOutput(output) {
        this.output = output;
      }
      setDebugMode(enabled) {
        this.debugMode = enabled;
      }
      _print(type, ...args) {
        if (!this.debugMode) return;
        if (this.output === noop || typeof this.output !== "function") return;
        this.output(`[${type}] [BARE_RPC]`, ...args);
      }
      log(...args) {
        this._print("LOG", ...args);
      }
      debug(...args) {
        this._print("DEBUG", ...args);
      }
      info(...args) {
        this._print("INFO", ...args);
      }
      warn(...args) {
        this._print("WARN", ...args);
      }
      error(...args) {
        this._print("ERROR", ...args);
      }
    };
    workletLogger = new WorkletLogger({ debugMode: false });
    workletLogger.setDebugMode(false);
    workletLogger.setLogOutput(noop);
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/api.js
var API, API_BY_VALUE;
var init_api = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/api.js"() {
    API = {
      STORAGE_PATH_SET: 1,
      MASTER_VAULT_INIT: 2,
      MASTER_VAULT_GET_STATUS: 3,
      MASTER_VAULT_GET: 4,
      MASTER_VAULT_CLOSE: 5,
      MASTER_VAULT_ADD: 6,
      MASTER_VAULT_LIST: 7,
      ACTIVE_VAULT_FILE_ADD: 8,
      ACTIVE_VAULT_FILE_REMOVE: 9,
      ACTIVE_VAULT_FILE_GET: 10,
      ACTIVE_VAULT_INIT: 11,
      ACTIVE_VAULT_GET_STATUS: 12,
      ACTIVE_VAULT_CLOSE: 13,
      ACTIVE_VAULT_ADD: 14,
      ACTIVE_VAULT_REMOVE: 15,
      ACTIVE_VAULT_LIST: 16,
      ACTIVE_VAULT_GET: 17,
      ACTIVE_VAULT_CREATE_INVITE: 18,
      ACTIVE_VAULT_DELETE_INVITE: 19,
      PAIR_ACTIVE_VAULT: 20,
      INIT_LISTENER: 21,
      ON_UPDATE: 22,
      ENCRYPTION_INIT: 23,
      ENCRYPTION_GET_STATUS: 24,
      ENCRYPTION_GET: 25,
      ENCRYPTION_ADD: 26,
      ENCRYPTION_CLOSE: 27,
      ENCRYPTION_HASH_PASSWORD: 28,
      ENCRYPTION_ENCRYPT_VAULT_KEY_WITH_HASHED_PASSWORD: 29,
      ENCRYPTION_ENCRYPT_VAULT_WITH_KEY: 30,
      ENCRYPTION_DECRYPT_VAULT_KEY: 31,
      ENCRYPTION_GET_DECRYPTION_KEY: 32,
      CLOSE_ALL_INSTANCES: 33,
      CANCEL_PAIR_ACTIVE_VAULT: 34,
      BLIND_MIRRORS_GET: 35,
      BLIND_MIRRORS_ADD: 36,
      BLIND_MIRROR_REMOVE: 37,
      BLIND_MIRRORS_ADD_DEFAULTS: 38,
      BLIND_MIRRORS_REMOVE_ALL: 39,
      MASTER_PASSWORD_STATUS: 40,
      RECORD_FAILED_MASTER_PASSWORD: 41,
      RESET_FAILED_ATTEMPTS: 42,
      MASTER_PASSWORD_CREATE: 43,
      MASTER_PASSWORD_INIT_WITH_PASSWORD: 44,
      MASTER_PASSWORD_UPDATE: 45,
      MASTER_PASSWORD_INIT_WITH_CREDENTIALS: 46,
      SET_CORE_STORE_OPTIONS: 49,
      SET_JOB_STORAGE_PATH: 50,
      READ_JOB_QUEUE: 51,
      WRITE_JOB_QUEUE: 52,
      FETCH_FAVICON: 53,
      ENCRYPTION_ENCRYPT_EXPORT_DATA: 54,
      ENCRYPTION_DECRYPT_EXPORT_DATA: 55,
      GENERATE_OTP_CODES_BY_IDS: 56,
      GENERATE_HOTP_NEXT: 57,
      ADD_OTP_TO_RECORD: 58,
      REMOVE_OTP_FROM_RECORD: 59
    };
    API_BY_VALUE = Object.entries(API).reduce((acc, [key, value]) => {
      acc[value] = key;
      return acc;
    }, {});
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/getForbiddenRoots.js
var getForbiddenRoots;
var init_getForbiddenRoots = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/getForbiddenRoots.js"() {
    getForbiddenRoots = () => {
      const isWindows = Bare.platform === "win32";
      const isMac = Bare.platform === "darwin";
      if (isWindows) {
        return [
          "C:\\Windows",
          "C:\\Windows\\System32",
          "C:\\Windows\\SysWOW64",
          "C:\\Program Files",
          "C:\\Program Files (x86)",
          "C:\\Program Files\\WindowsApps",
          "C:\\ProgramData",
          "C:\\System Volume Information"
        ];
      }
      if (isMac) {
        return [
          "/bin",
          "/sbin",
          "/usr/bin",
          "/usr/sbin",
          "/etc",
          "/var",
          "/tmp",
          "/root",
          "/boot",
          "/sys",
          "/proc",
          "/dev",
          "/System",
          "/Library",
          "/private"
        ];
      }
      return [
        "/bin",
        "/sbin",
        "/usr/bin",
        "/usr/sbin",
        "/etc",
        "/var",
        "/tmp",
        "/root",
        "/boot",
        "/sys",
        "/proc",
        "/dev",
        "/lib",
        "/lib64"
      ];
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/constants/otpType.js
var OTP_TYPE;
var init_otpType = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/constants/otpType.js"() {
    OTP_TYPE = {
      TOTP: "TOTP",
      HOTP: "HOTP"
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/otp/index.js
var OTPAuth, isOtpauthUri, parseOtpauthUri, parseOtpInput, getTimeRemaining, generateTOTP, generateHOTP;
var init_otp = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/otp/index.js"() {
    OTPAuth = __toESM(require("otpauth/dist/otpauth.esm.js"), 1);
    init_otpType();
    isOtpauthUri = (input) => typeof input === "string" && input.startsWith("otpauth://");
    parseOtpauthUri = (uri) => {
      const parsed = OTPAuth.URI.parse(uri);
      const config = {
        secret: parsed.secret.base32,
        type: parsed instanceof OTPAuth.TOTP ? OTP_TYPE.TOTP : OTP_TYPE.HOTP,
        algorithm: parsed.algorithm,
        digits: parsed.digits
      };
      if (config.type === OTP_TYPE.TOTP) {
        config.period = parsed.period;
      } else {
        config.counter = parsed.counter;
      }
      if (parsed.issuer) {
        config.issuer = parsed.issuer;
      }
      if (parsed.label) {
        config.label = parsed.label;
      }
      return config;
    };
    parseOtpInput = (input) => {
      if (!input || typeof input !== "string") {
        throw new Error("OTP input is required");
      }
      const trimmed = input.trim();
      if (isOtpauthUri(trimmed)) {
        return parseOtpauthUri(trimmed);
      }
      return {
        secret: trimmed,
        type: OTP_TYPE.TOTP,
        algorithm: "SHA1",
        digits: 6,
        period: 30
      };
    };
    getTimeRemaining = (period = 30) => {
      const now = Math.floor(Date.now() / 1e3);
      return period - now % period;
    };
    generateTOTP = (otpConfig) => {
      const totp = new OTPAuth.TOTP({
        secret: OTPAuth.Secret.fromBase32(otpConfig.secret),
        algorithm: otpConfig.algorithm || "SHA1",
        digits: otpConfig.digits || 6,
        period: otpConfig.period || 30,
        issuer: otpConfig.issuer,
        label: otpConfig.label
      });
      const code = totp.generate();
      const timeRemaining = getTimeRemaining(otpConfig.period || 30);
      return { code, timeRemaining };
    };
    generateHOTP = (otpConfig) => {
      const hotp = new OTPAuth.HOTP({
        secret: OTPAuth.Secret.fromBase32(otpConfig.secret),
        algorithm: otpConfig.algorithm || "SHA1",
        digits: otpConfig.digits || 6,
        counter: otpConfig.counter || 0,
        issuer: otpConfig.issuer,
        label: otpConfig.label
      });
      const code = hotp.generate({ counter: otpConfig.counter || 0 });
      return { code };
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/utils/swarm.js
async function getConfig(store) {
  try {
    const Swarmconf = require("@tetherto/swarmconf");
    const conf = new Swarmconf(store);
    await conf.ready();
    return conf;
  } catch {
    return {
      current: {
        version: 0,
        blindRelays: [],
        blindPeers: []
      }
    };
  }
}
var init_swarm = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/utils/swarm.js"() {
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/pearpassPairer.js
var import_autopass, import_b4a, import_blind_encryption_sodium, import_corestore, PearPassPairer;
var init_pearpassPairer = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/pearpassPairer.js"() {
    import_autopass = __toESM(require("autopass"), 1);
    import_b4a = __toESM(require("b4a"), 1);
    import_blind_encryption_sodium = __toESM(require("blind-encryption-sodium"), 1);
    import_corestore = __toESM(require("corestore"), 1);
    init_appDeps();
    init_swarm();
    PearPassPairer = class {
      constructor() {
        this.store = null;
        this.pair = null;
        this._cleanupInFlight = Promise.resolve();
      }
      async pairInstance(path, invite) {
        await this.cancelPairing();
        const store = new import_corestore.default(path);
        this.store = store;
        if (!store) {
          throw new Error("Error creating store");
        }
        const conf = await getConfig(store);
        const hashedPassword = await getHashedPassword();
        if (!hashedPassword) {
          throw new Error("Hashed password not found");
        }
        const pair = import_autopass.default.pair(store, invite, {
          relayThrough: conf.current.blindRelays,
          blindEncryption: new import_blind_encryption_sodium.default(
            import_b4a.default.alloc(32, hashedPassword, "utf-8")
          )
        });
        this.pair = pair;
        try {
          const instance = await pair.finished();
          await instance.ready();
          const encryptionKey = instance.encryptionKey.toString("base64");
          await instance.close();
          return encryptionKey;
        } catch (error) {
          throw new Error(`Pairing failed: ${error.message}`);
        } finally {
          await this.cancelPairing();
        }
      }
      async cancelPairing() {
        this._cleanupInFlight = this._cleanupInFlight.then(async () => {
          const pair = this.pair;
          const store = this.store;
          this.pair = null;
          this.store = null;
          try {
            await pair?.close();
          } catch {
          }
          try {
            await store?.close();
          } catch {
          }
        });
        await this._cleanupInFlight;
      }
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/rateLimiter.js
var MAX_ATTEMPTS, MAX_BACKOFF_MINUTES, COOLDOWN_PERIOD_MS, STORAGE_KEY, DEFAULT_DATA, RateLimiter;
var init_rateLimiter = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/rateLimiter.js"() {
    MAX_ATTEMPTS = 5;
    MAX_BACKOFF_MINUTES = 24 * 60;
    COOLDOWN_PERIOD_MS = MAX_BACKOFF_MINUTES * 60 * 1e3;
    STORAGE_KEY = "rateLimitData";
    DEFAULT_DATA = {
      consecutiveFailures: 0,
      lockoutUntil: null,
      lastAttemptTime: null
    };
    RateLimiter = class {
      constructor() {
        this.storage = null;
      }
      async setStorage(storage) {
        if (!storage) {
          throw new Error("Storage must have get and add methods");
        }
        this.storage = storage;
      }
      /**
       * @param {number} consecutiveFailures
       * @returns {number}
       */
      calculateBackoffDuration(consecutiveFailures) {
        if (consecutiveFailures < MAX_ATTEMPTS) {
          return 0;
        }
        const exponent = consecutiveFailures - MAX_ATTEMPTS + 1;
        const backoffMinutes = Math.pow(2, exponent);
        const cappedMinutes = Math.min(backoffMinutes, MAX_BACKOFF_MINUTES);
        return cappedMinutes * 60 * 1e3;
      }
      async getData() {
        if (!this.storage) {
          throw new Error("Storage not initialized.");
        }
        try {
          const data = await this.storage.get(STORAGE_KEY);
          return data || { ...DEFAULT_DATA };
        } catch {
          const backoffMs = this.calculateBackoffDuration(1);
          return {
            consecutiveFailures: 1,
            lockoutUntil: Date.now() + backoffMs,
            lastAttemptTime: Date.now()
          };
        }
      }
      isLockoutExpired(lockoutUntil) {
        if (lockoutUntil === null) {
          return true;
        }
        return Date.now() >= lockoutUntil;
      }
      /**
       * @param {number|null} lastAttemptTime
       * @returns {boolean}
       */
      shouldGrantFreshStart(lastAttemptTime) {
        if (lastAttemptTime === null) {
          return false;
        }
        return Date.now() - lastAttemptTime >= COOLDOWN_PERIOD_MS;
      }
      async getStatus() {
        const data = await this.getData();
        if (this.shouldGrantFreshStart(data.lastAttemptTime)) {
          await this.reset();
          return {
            isLocked: false,
            lockoutRemainingMs: 0,
            remainingAttempts: MAX_ATTEMPTS
          };
        }
        if (data.lockoutUntil !== null && this.isLockoutExpired(data.lockoutUntil)) {
          return {
            isLocked: false,
            lockoutRemainingMs: 0,
            remainingAttempts: 0
          };
        }
        const isLocked = data.lockoutUntil !== null;
        const lockoutRemainingMs = data.lockoutUntil ? Math.max(0, data.lockoutUntil - Date.now()) : 0;
        const remainingAttempts = isLocked ? 0 : Math.max(0, MAX_ATTEMPTS - data.consecutiveFailures);
        return { isLocked, lockoutRemainingMs, remainingAttempts };
      }
      async getRemainingAttempts() {
        const data = await this.getData();
        if (this.shouldGrantFreshStart(data.lastAttemptTime)) {
          return MAX_ATTEMPTS;
        }
        if (data.lockoutUntil !== null && !this.isLockoutExpired(data.lockoutUntil)) {
          return 0;
        }
        return Math.max(0, MAX_ATTEMPTS - data.consecutiveFailures);
      }
      async recordFailure() {
        let data;
        try {
          data = await this.getData();
        } catch {
          throw new Error("Rate limiter unavailable - denying attempt");
        }
        if (this.shouldGrantFreshStart(data.lastAttemptTime)) {
          data.consecutiveFailures = 0;
          data.lockoutUntil = null;
        }
        if (data.lockoutUntil !== null && this.isLockoutExpired(data.lockoutUntil)) {
          data.lockoutUntil = null;
        }
        data.consecutiveFailures++;
        data.lastAttemptTime = Date.now();
        const backoffMs = this.calculateBackoffDuration(data.consecutiveFailures);
        if (backoffMs > 0) {
          data.lockoutUntil = Date.now() + backoffMs;
        } else {
          data.lockoutUntil = null;
        }
        try {
          await this.storage.add(STORAGE_KEY, data);
        } catch {
          throw new Error("Failed to record attempt - denying access");
        }
      }
      async reset() {
        await this.storage.add(STORAGE_KEY, { ...DEFAULT_DATA });
      }
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/validateAndSanitizePath.js
var import_bare_path, WHITELISTED_DOT_DIRS, validateAndSanitizePath;
var init_validateAndSanitizePath = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/validateAndSanitizePath.js"() {
    import_bare_path = __toESM(require("bare-path"), 1);
    WHITELISTED_DOT_DIRS = [".config"];
    validateAndSanitizePath = (rawPath) => {
      if (!rawPath || typeof rawPath !== "string") {
        throw new Error("Storage path must be a non-empty string");
      }
      let cleanPath = rawPath;
      if (cleanPath.startsWith("file://")) {
        cleanPath = cleanPath.substring("file://".length);
      }
      cleanPath = cleanPath.trim();
      if (cleanPath.length === 0) {
        throw new Error("Storage path cannot be empty after sanitization");
      }
      try {
        cleanPath = decodeURIComponent(cleanPath);
      } catch {
        throw new Error("Storage path contains invalid URL encoding");
      }
      if (cleanPath.includes("\0")) {
        throw new Error("Storage path contains invalid null bytes");
      }
      const dangerousUnicodePattern = /[\u0001-\u001F\u007F-\u009F\u200B-\u200D\u202A-\u202E\u2066-\u2069\uFEFF]/;
      if (dangerousUnicodePattern.test(cleanPath)) {
        throw new Error("Storage path contains invalid control characters");
      }
      if (!import_bare_path.default.isAbsolute(cleanPath)) {
        throw new Error("Storage path must be an absolute path");
      }
      if (cleanPath.includes("..") || cleanPath.includes("./")) {
        throw new Error(
          "Storage path must not contain traversal sequences (. or ..)"
        );
      }
      const dotPattern = /\/\.([^/]+)/g;
      const matches = [...cleanPath.matchAll(dotPattern)];
      for (const match of matches) {
        if (!WHITELISTED_DOT_DIRS.includes(`.${match[1]}`)) {
          throw new Error(
            "Storage path must not contain traversal sequences (. or ..)"
          );
        }
      }
      cleanPath = import_bare_path.default.normalize(cleanPath);
      return cleanPath;
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/constants/defaultBlindMirrors.js
var defaultMirrorKeys;
var init_defaultBlindMirrors = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/constants/defaultBlindMirrors.js"() {
    defaultMirrorKeys = [
      "xtbtf7itx51uxj843i11a7if646sppwgqpuf9gdfofddrgjm9xhy",
      "g6g8hqaju7mijj6g4f9guombuqdgprz4jbdfutydkbr97gbnkhpy",
      "1mepwwg7544apseebbpno854p75hazxj6c7696wp4k1hnpake8so",
      "phwfybneotpgcymcs9cd3z5ay7g7ixsr88wfcbmc6rpczz15xudo"
    ];
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/appDeps.js
var import_autopass2, import_b4a2, import_bare_fs, import_bare_path2, import_blind_encryption_sodium2, import_corestore2, import_sodium_native, STORAGE_PATH, JOB_STORAGE_PATH, JOB_FILE_NAME, JOB_FILE_MAGIC, JOB_FILE_HEADER_SIZE, JOB_FILE_NONCE_SIZE, CORE_STORE_OPTIONS, encryptionInstance, isEncryptionInitialized, vaultsInstance, isVaultsInitialized, activeVaultInstance, isActiveVaultInitialized, listeningVaultId, lastActiveVaultId, lastActiveVaultEncryptionKey, lastOnUpdateCallback, pearpassPairer, rateLimiter, setStoragePath, setCoreStoreOptions, getIsVaultsInitialized, getIsEncryptionInitialized, getIsActiveVaultInitialized, suspendAllInstances, resumeAllInstances, clearRestartCache, closeActiveVaultInstance, collectValuesByFilter, buildPath, initInstance, initInstanceWithNewBlindEncryption, initActiveVaultInstance, rateLimitInit, rateLimitRecordFailure, getRateLimitStatus, resetRateLimit, masterVaultInit, masterVaultInitWithNewBlindEncryption, encryptionInit, encryptionGet, encryptionAdd, encryptionClose, closeVaultsInstance, activeVaultAdd, vaultsGet, vaultsAdd, activeVaultGetFile, activeVaultRemoveFile, vaultRemove, vaultsList, activeVaultList, activeVaultGet, createInvite, deleteInvite, pairActiveVault, cancelPairActiveVault, initListener, restartActiveVault, closeAllInstances, getBlindMirrors, setMirrorMetadata, addBlindMirrors, removeBlindMirror, addDefaultBlindMirrors, removeAllBlindMirrors, getHashedPassword, setJobStoragePath, buildJobPath, readAndDecryptJobFile, writeAndEncryptJobFile, activeVaultGetRaw, enrichRecordForClient, generateOtpCodesByIds, generateHotpNext, addOtpToRecord, removeOtpFromRecord;
var init_appDeps = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/appDeps.js"() {
    import_autopass2 = __toESM(require("autopass"), 1);
    import_b4a2 = __toESM(require("b4a"), 1);
    import_bare_fs = __toESM(require("bare-fs"), 1);
    import_bare_path2 = __toESM(require("bare-path"), 1);
    import_blind_encryption_sodium2 = __toESM(require("blind-encryption-sodium"), 1);
    import_corestore2 = __toESM(require("corestore"), 1);
    import_sodium_native = __toESM(require("sodium-native"), 1);
    init_getForbiddenRoots();
    init_otp();
    init_pearpassPairer();
    init_rateLimiter();
    init_workletLogger();
    init_otpType();
    init_swarm();
    init_validateAndSanitizePath();
    init_defaultBlindMirrors();
    STORAGE_PATH = null;
    JOB_STORAGE_PATH = null;
    JOB_FILE_NAME = "jobs.enc";
    JOB_FILE_MAGIC = "PPJQ";
    JOB_FILE_HEADER_SIZE = 16;
    JOB_FILE_NONCE_SIZE = import_sodium_native.default.crypto_secretbox_NONCEBYTES;
    CORE_STORE_OPTIONS = {
      readOnly: false,
      suspend: true
    };
    isEncryptionInitialized = false;
    isVaultsInitialized = false;
    isActiveVaultInitialized = false;
    listeningVaultId = null;
    lastActiveVaultId = null;
    lastActiveVaultEncryptionKey = null;
    lastOnUpdateCallback = null;
    pearpassPairer = new PearPassPairer();
    rateLimiter = new RateLimiter();
    setStoragePath = async (path) => {
      const sanitizedPath = validateAndSanitizePath(path);
      const forbiddenRoots = getForbiddenRoots();
      const isWindows = Bare.platform === "win32";
      for (const root of forbiddenRoots) {
        const normalizedRoot = isWindows ? root.toLowerCase() : root;
        const normalizedPath = isWindows ? sanitizedPath.toLowerCase() : sanitizedPath;
        const separator = isWindows ? "\\" : "/";
        if (normalizedPath === normalizedRoot || normalizedPath.startsWith(normalizedRoot + separator)) {
          throw new Error("Storage path points to a restricted system directory");
        }
      }
      STORAGE_PATH = sanitizedPath;
    };
    setCoreStoreOptions = (coreStoreOptions) => {
      CORE_STORE_OPTIONS = {
        readOnly: false,
        ...coreStoreOptions
      };
    };
    getIsVaultsInitialized = () => isVaultsInitialized;
    getIsEncryptionInitialized = () => isEncryptionInitialized;
    getIsActiveVaultInitialized = () => isActiveVaultInitialized;
    suspendAllInstances = async () => {
      const tasks = [];
      tasks.push(activeVaultInstance?.suspend?.());
      tasks.push(vaultsInstance?.suspend?.());
      tasks.push(encryptionInstance?.suspend?.());
      await Promise.allSettled(tasks);
    };
    resumeAllInstances = async () => {
      const tasks = [];
      tasks.push(activeVaultInstance?.resume?.());
      tasks.push(vaultsInstance?.resume?.());
      tasks.push(encryptionInstance?.resume?.());
      await Promise.allSettled(tasks);
    };
    clearRestartCache = () => {
      lastActiveVaultId = null;
      lastActiveVaultEncryptionKey = null;
      lastOnUpdateCallback = null;
    };
    closeActiveVaultInstance = async (options) => {
      activeVaultInstance.removeAllListeners();
      await activeVaultInstance.close();
      activeVaultInstance = null;
      isActiveVaultInitialized = false;
      listeningVaultId = null;
      if (options?.clearRestartCache) {
        clearRestartCache();
      }
    };
    collectValuesByFilter = async (instance, filterFn) => {
      const stream = await instance.list();
      const results = [];
      return new Promise((resolve, reject) => {
        stream.on("data", ({ key, value }) => {
          if (!value) {
            return;
          }
          const parsedValue = JSON.parse(value);
          if (!parsedValue) {
            return;
          }
          if (!filterFn) {
            results.push(parsedValue);
            return;
          }
          if (filterFn(key)) {
            results.push(parsedValue);
          }
        });
        stream.on("end", () => resolve(results));
        stream.on("error", (error) => reject(error));
      });
    };
    buildPath = (path) => {
      if (!STORAGE_PATH) {
        throw new Error("Storage path not set");
      }
      const resolved = import_bare_path2.default.join(STORAGE_PATH, path);
      const normalizedRoot = import_bare_path2.default.normalize(STORAGE_PATH);
      const normalizedResolved = import_bare_path2.default.normalize(resolved);
      if (normalizedResolved !== normalizedRoot && !normalizedResolved.startsWith(normalizedRoot + import_bare_path2.default.sep)) {
        throw new Error("Resolved path escapes storage root");
      }
      return normalizedResolved;
    };
    initInstance = async ({ path, hashedPassword, encryptionKey }) => {
      try {
        const fullPath = buildPath(path);
        const store = new import_corestore2.default(fullPath, CORE_STORE_OPTIONS);
        if (!store) {
          throw new Error("Error creating store");
        }
        const conf = await getConfig(store);
        const instance = new import_autopass2.default(store, {
          encryptionKey: encryptionKey ? Buffer.from(encryptionKey, "base64") : void 0,
          blindEncryption: hashedPassword ? new import_blind_encryption_sodium2.default(import_b4a2.default.alloc(32, hashedPassword, "utf-8")) : void 0,
          relayThrough: conf.current.blindRelays
        });
        await instance.ready();
        return instance;
      } catch (error) {
        throw new Error(`Error initializing instance: ${error.message}`);
      }
    };
    initInstanceWithNewBlindEncryption = async ({
      path,
      encryptionKey,
      newHashedPassword,
      currentHashedPassword
    }) => {
      try {
        if (!currentHashedPassword || !newHashedPassword) {
          throw new Error("Old and new hashed passwords are required");
        }
        const fullPath = buildPath(path);
        const store = new import_corestore2.default(fullPath, CORE_STORE_OPTIONS);
        if (!store) {
          throw new Error("Error creating store");
        }
        const conf = await getConfig(store);
        const instance = new import_autopass2.default(store, {
          encryptionKey: encryptionKey ? Buffer.from(encryptionKey, "base64") : void 0,
          blindEncryption: new import_blind_encryption_sodium2.default(
            import_b4a2.default.alloc(32, newHashedPassword, "utf-8"),
            import_b4a2.default.alloc(32, currentHashedPassword, "utf-8")
          ),
          relayThrough: conf.current.blindRelays
        });
        await instance.ready();
        return instance;
      } catch (error) {
        throw new Error(
          `Error initializing instance with new blind encryption: ${error.message}`
        );
      }
    };
    initActiveVaultInstance = async ({ id: id2, encryptionKey }) => {
      isActiveVaultInitialized = false;
      const hashedPassword = await getHashedPassword();
      activeVaultInstance = await initInstance({
        path: `vault/${id2}`,
        encryptionKey,
        hashedPassword
      });
      await activeVaultInstance.base.update();
      isActiveVaultInitialized = true;
      lastActiveVaultId = id2;
      lastActiveVaultEncryptionKey = encryptionKey;
      if (lastOnUpdateCallback) {
        lastOnUpdateCallback();
      }
      return activeVaultInstance;
    };
    rateLimitInit = async () => {
      if (!isEncryptionInitialized) {
        return;
      }
      await rateLimiter.setStorage({
        get: encryptionGet,
        add: encryptionAdd
      });
    };
    rateLimitRecordFailure = async () => {
      await rateLimiter.recordFailure();
    };
    getRateLimitStatus = async () => {
      await rateLimitInit();
      return await rateLimiter.getStatus();
    };
    resetRateLimit = async () => {
      await rateLimiter.reset();
    };
    masterVaultInit = async ({ encryptionKey, hashedPassword }) => {
      isVaultsInitialized = false;
      vaultsInstance = await initInstance({
        path: "vaults",
        encryptionKey,
        hashedPassword
      });
      isVaultsInitialized = true;
    };
    masterVaultInitWithNewBlindEncryption = async ({
      encryptionKey,
      newHashedPassword,
      currentHashedPassword
    }) => {
      isVaultsInitialized = false;
      vaultsInstance = await initInstanceWithNewBlindEncryption({
        path: "vaults",
        encryptionKey,
        newHashedPassword,
        currentHashedPassword
      });
      isVaultsInitialized = true;
    };
    encryptionInit = async () => {
      isEncryptionInitialized = false;
      encryptionInstance = await initInstance({
        path: "encryption"
      });
      isEncryptionInitialized = true;
    };
    encryptionGet = async (key) => {
      if (!isEncryptionInitialized) {
        throw new Error("Encryption not initialised");
      }
      const res = await encryptionInstance.get(key);
      const { value } = res || {};
      const parsedRes = value ? JSON.parse(value) : null;
      return parsedRes;
    };
    encryptionAdd = async (key, data) => {
      if (!isEncryptionInitialized) {
        throw new Error("Encryption not initialised");
      }
      await encryptionInstance.add(key, JSON.stringify(data));
    };
    encryptionClose = async () => {
      await encryptionInstance.close();
      encryptionInstance = null;
      isEncryptionInitialized = false;
    };
    closeVaultsInstance = async () => {
      await vaultsInstance.close();
      vaultsInstance = null;
      isVaultsInitialized = false;
    };
    activeVaultAdd = async (key, data, file, fileName) => {
      if (!isActiveVaultInitialized) {
        throw new Error("Vault not initialised");
      }
      try {
        await activeVaultInstance.add(key, JSON.stringify(data), file);
      } catch (error) {
        const err = new Error(error.message);
        if (fileName) {
          err.details = { fileName };
        }
        throw err;
      }
    };
    vaultsGet = async (key) => {
      if (!isVaultsInitialized) {
        throw new Error("Vaults not initialised");
      }
      const res = await vaultsInstance.get(key);
      const { value, file } = res || {};
      const parsedValue = JSON.parse(value);
      if (file) {
        Object.defineProperty(parsedValue, "file", {
          value: file,
          enumerable: true
        });
      }
      return parsedValue;
    };
    vaultsAdd = async (key, data) => {
      if (!isVaultsInitialized) {
        throw new Error("Vault not initialised");
      }
      await vaultsInstance.add(key, JSON.stringify(data));
    };
    activeVaultGetFile = async (key) => {
      if (!isActiveVaultInitialized) {
        throw new Error("Vault not initialised");
      }
      const res = await activeVaultInstance.get(key);
      return res?.file || null;
    };
    activeVaultRemoveFile = async (key) => {
      if (!isActiveVaultInitialized) {
        throw new Error("Vault not initialised");
      }
      await activeVaultInstance.remove(key);
    };
    vaultRemove = async (key) => {
      if (!isActiveVaultInitialized) {
        throw new Error("Vault not initialised");
      }
      await activeVaultInstance.remove(key);
    };
    vaultsList = async (filterKey) => {
      if (!isVaultsInitialized) {
        throw new Error("Vaults not initialised");
      }
      return collectValuesByFilter(
        vaultsInstance,
        filterKey ? (key) => key?.startsWith(filterKey) : void 0
      );
    };
    activeVaultList = async (filterKey) => {
      if (!isActiveVaultInitialized) {
        throw new Error("Vault not initialised");
      }
      const results = await collectValuesByFilter(
        activeVaultInstance,
        filterKey ? (key) => key?.startsWith(filterKey) : void 0
      );
      if (filterKey?.startsWith("record/")) {
        return results.map(enrichRecordForClient);
      }
      return results;
    };
    activeVaultGet = async (key) => {
      if (!isActiveVaultInitialized) {
        throw new Error("Vault not initialised");
      }
      const res = await activeVaultInstance.get(key);
      if (!res || !res.value) {
        return null;
      }
      const { value, file } = res || {};
      const parsedValue = JSON.parse(value);
      if (file) {
        Object.defineProperty(parsedValue, "file", {
          value: file,
          enumerable: true
        });
      }
      if (key?.startsWith("record/")) {
        return enrichRecordForClient(parsedValue);
      }
      return parsedValue;
    };
    createInvite = async () => {
      await activeVaultInstance.deleteInvite();
      const inviteCode = await activeVaultInstance.createInvite();
      const response = await activeVaultInstance.get("vault");
      const { value: vault } = response || {};
      if (!vault) {
        throw new Error("Vault not found");
      }
      const parsedVault = JSON.parse(vault);
      const vaultId = parsedVault.id;
      return `${vaultId}/${inviteCode}`;
    };
    deleteInvite = async () => {
      await activeVaultInstance.deleteInvite();
      const response = await activeVaultInstance.get("vault");
      const { value: vault } = response || {};
      if (!vault) {
        throw new Error("Vault not found");
      }
    };
    pairActiveVault = async (inviteCode) => {
      const wasActive = isActiveVaultInitialized;
      try {
        const [vaultId, inviteKey] = inviteCode.split("/");
        if (isActiveVaultInitialized) {
          await closeActiveVaultInstance();
        }
        const encryptionKey = await pearpassPairer.pairInstance(
          buildPath(`vault/${vaultId}`),
          inviteKey
        );
        return { vaultId, encryptionKey };
      } catch (error) {
        if (wasActive) {
          try {
            await restartActiveVault();
          } catch {
            throw new Error(`Pairing failed: ${error.message}`);
          }
        }
        throw new Error(`Pairing failed: ${error.message}`);
      }
    };
    cancelPairActiveVault = async () => {
      await pearpassPairer.cancelPairing();
    };
    initListener = async ({ vaultId, onUpdate }) => {
      if (vaultId === listeningVaultId) {
        return;
      }
      activeVaultInstance.removeAllListeners();
      activeVaultInstance.on("update", () => {
        onUpdate?.();
      });
      listeningVaultId = vaultId;
      lastOnUpdateCallback = onUpdate;
    };
    restartActiveVault = async () => {
      if (!lastActiveVaultId) {
        throw new Error("[restartActiveVault]: No previous active vault to restart");
      }
      if (isActiveVaultInitialized) {
        await closeActiveVaultInstance();
      }
      await initActiveVaultInstance({
        id: lastActiveVaultId,
        encryptionKey: lastActiveVaultEncryptionKey
      });
      if (lastOnUpdateCallback) {
        await initListener({
          vaultId: lastActiveVaultId,
          onUpdate: lastOnUpdateCallback
        });
      }
    };
    closeAllInstances = async () => {
      const closeTasks = [];
      if (isActiveVaultInitialized) {
        closeTasks.push(closeActiveVaultInstance());
      }
      if (isVaultsInitialized) {
        closeTasks.push(closeVaultsInstance());
      }
      if (isEncryptionInitialized) {
        closeTasks.push(encryptionClose());
      }
      await Promise.all(closeTasks);
      clearRestartCache();
    };
    getBlindMirrors = async () => {
      if (!isActiveVaultInitialized) {
        throw new Error("[getBlindMirrors]: Vault not initialised");
      }
      const mirrors = await activeVaultInstance.getMirror();
      const mirrorsArray = Array.isArray(mirrors) ? mirrors : [];
      try {
        const metadata = await activeVaultGet("mirror-metadata");
        const isDefault = metadata?.isDefault ?? false;
        const enrichedMirrors = mirrorsArray.map((mirror) => ({
          ...mirror,
          isDefault
        }));
        return enrichedMirrors;
      } catch (error) {
        throw new Error(
          `[getBlindMirrors]: Failed to get mirror metadata: ${error?.message || "Unexpected error"}`
        );
      }
    };
    setMirrorMetadata = async (isDefault) => {
      await activeVaultAdd("mirror-metadata", { isDefault });
    };
    addBlindMirrors = async (mirrors) => {
      if (!isActiveVaultInitialized) {
        throw new Error("[addBlindMirrors]: Vault not initialised");
      }
      if (!Array.isArray(mirrors) || mirrors.length === 0) {
        throw new Error("[addBlindMirrors]: No mirrors provided");
      }
      await Promise.all(
        mirrors.map((mirror) => activeVaultInstance.addMirror(mirror))
      );
      await setMirrorMetadata(false);
    };
    removeBlindMirror = async (key) => {
      if (!isActiveVaultInitialized) {
        throw new Error("[removeBlindMirror]: Vault not initialised");
      }
      if (!key) {
        throw new Error("[removeBlindMirror]: mirror key not provided!");
      }
      await activeVaultInstance.removeMirror(key);
    };
    addDefaultBlindMirrors = async () => {
      if (!isActiveVaultInitialized) {
        throw new Error("[addDefaultBlindMirrors]: Vault not initialised");
      }
      await Promise.all(
        defaultMirrorKeys.map((key) => activeVaultInstance.addMirror(key))
      );
      await setMirrorMetadata(true);
    };
    removeAllBlindMirrors = async () => {
      if (!isActiveVaultInitialized) {
        throw new Error("[removeAllBlindMirrors]: Vault not initialised");
      }
      const currentMirrors = await activeVaultInstance.getMirror();
      const currentKeys = (Array.isArray(currentMirrors) ? currentMirrors : []).map(
        (m) => m?.key
      );
      await Promise.all(
        currentKeys.map((key) => activeVaultInstance.removeMirror(key))
      );
      await vaultRemove("mirror-metadata");
    };
    getHashedPassword = async () => {
      const masterEncryption = await vaultsGet("masterEncryption");
      return masterEncryption?.hashedPassword;
    };
    setJobStoragePath = (path) => {
      const sanitizedPath = validateAndSanitizePath(path);
      JOB_STORAGE_PATH = sanitizedPath;
    };
    buildJobPath = (relativePath) => {
      if (!JOB_STORAGE_PATH) {
        throw new Error("JOB_STORAGE_PATH not set");
      }
      const resolved = import_bare_path2.default.join(JOB_STORAGE_PATH, relativePath);
      const normalizedRoot = import_bare_path2.default.normalize(JOB_STORAGE_PATH);
      const normalizedResolved = import_bare_path2.default.normalize(resolved);
      if (normalizedResolved !== normalizedRoot && !normalizedResolved.startsWith(normalizedRoot + import_bare_path2.default.sep)) {
        throw new Error("Path traversal detected");
      }
      return normalizedResolved;
    };
    readAndDecryptJobFile = async () => {
      const hashedPasswordHex = await getHashedPassword();
      if (!hashedPasswordHex) {
        return [];
      }
      const filePath = buildJobPath(JOB_FILE_NAME);
      let fileData;
      try {
        fileData = import_bare_fs.default.readFileSync(filePath);
      } catch (err) {
        if (err.code === "ENOENT") {
          return [];
        }
        throw err;
      }
      if (fileData.length < JOB_FILE_HEADER_SIZE + JOB_FILE_NONCE_SIZE) {
        throw new Error("Job file too small");
      }
      const magic = fileData.slice(0, 4).toString("utf-8");
      if (magic !== JOB_FILE_MAGIC) {
        throw new Error("Invalid job file magic bytes");
      }
      const version = fileData.readUInt16LE(4);
      if (version !== 1) {
        throw new Error(`Unsupported job file version: ${version}`);
      }
      const nonce = fileData.slice(
        JOB_FILE_HEADER_SIZE,
        JOB_FILE_HEADER_SIZE + JOB_FILE_NONCE_SIZE
      );
      const ciphertext = fileData.slice(JOB_FILE_HEADER_SIZE + JOB_FILE_NONCE_SIZE);
      if (ciphertext.length < import_sodium_native.default.crypto_secretbox_MACBYTES) {
        throw new Error("Job file ciphertext too small");
      }
      const key = import_sodium_native.default.sodium_malloc(import_sodium_native.default.crypto_secretbox_KEYBYTES);
      const plaintext = import_sodium_native.default.sodium_malloc(
        ciphertext.length - import_sodium_native.default.crypto_secretbox_MACBYTES
      );
      try {
        key.write(hashedPasswordHex, "hex");
        const opened = import_sodium_native.default.crypto_secretbox_open_easy(
          plaintext,
          ciphertext,
          nonce,
          key
        );
        if (!opened) {
          throw new Error("Failed to decrypt job file: authentication failed");
        }
        const json = plaintext.toString("utf-8");
        const parsed = JSON.parse(json);
        return parsed;
      } finally {
        import_sodium_native.default.sodium_memzero(key);
        import_sodium_native.default.sodium_memzero(plaintext);
        import_sodium_native.default.sodium_free(key);
        import_sodium_native.default.sodium_free(plaintext);
      }
    };
    writeAndEncryptJobFile = async (jobs) => {
      const hashedPasswordHex = await getHashedPassword();
      if (!hashedPasswordHex) {
        throw new Error("Not authenticated");
      }
      const filePath = buildJobPath(JOB_FILE_NAME);
      const tempPath = filePath + ".tmp";
      const dirPath = import_bare_path2.default.dirname(filePath);
      try {
        import_bare_fs.default.mkdirSync(dirPath, { recursive: true });
      } catch (err) {
        if (err.code !== "EEXIST") {
          throw err;
        }
      }
      const jsonBuffer = Buffer.from(JSON.stringify(jobs), "utf-8");
      const nonce = import_sodium_native.default.sodium_malloc(JOB_FILE_NONCE_SIZE);
      const key = import_sodium_native.default.sodium_malloc(import_sodium_native.default.crypto_secretbox_KEYBYTES);
      const ciphertext = import_sodium_native.default.sodium_malloc(
        jsonBuffer.length + import_sodium_native.default.crypto_secretbox_MACBYTES
      );
      try {
        import_sodium_native.default.randombytes_buf(nonce);
        key.write(hashedPasswordHex, "hex");
        import_sodium_native.default.crypto_secretbox_easy(ciphertext, jsonBuffer, nonce, key);
        const header = Buffer.alloc(JOB_FILE_HEADER_SIZE);
        header.write(JOB_FILE_MAGIC, 0, 4, "utf-8");
        header.writeUInt16LE(1, 4);
        header.writeUInt16LE(jobs.length, 6);
        const output = Buffer.concat([
          header,
          Buffer.from(nonce),
          Buffer.from(ciphertext)
        ]);
        import_bare_fs.default.writeFileSync(tempPath, output);
        import_bare_fs.default.renameSync(tempPath, filePath);
      } finally {
        import_sodium_native.default.sodium_memzero(nonce);
        import_sodium_native.default.sodium_memzero(key);
        import_sodium_native.default.sodium_memzero(ciphertext);
        import_sodium_native.default.sodium_free(nonce);
        import_sodium_native.default.sodium_free(key);
        import_sodium_native.default.sodium_free(ciphertext);
      }
    };
    activeVaultGetRaw = async (key) => {
      if (!isActiveVaultInitialized) {
        throw new Error("Vault not initialised");
      }
      const res = await activeVaultInstance.get(key);
      if (!res || !res.value) return null;
      return JSON.parse(res.value);
    };
    enrichRecordForClient = (record) => {
      if (!record?.data?.otp) {
        return record;
      }
      const otp = record.data.otp;
      const enriched = {
        ...record,
        data: { ...record.data }
      };
      try {
        const otpPublic = {
          type: otp.type,
          digits: otp.digits,
          issuer: otp.issuer,
          label: otp.label
        };
        if (otp.type === OTP_TYPE.TOTP) {
          const { code, timeRemaining } = generateTOTP(otp);
          otpPublic.period = otp.period;
          otpPublic.currentCode = code;
          otpPublic.timeRemaining = timeRemaining;
        } else if (otp.type === OTP_TYPE.HOTP) {
          const { code } = generateHOTP(otp);
          otpPublic.currentCode = code;
        }
        delete enriched.data.otp;
        enriched.otpPublic = otpPublic;
      } catch (error) {
        workletLogger.error("Failed to enrich record with OTP data:", error);
        delete enriched.data.otp;
      }
      return enriched;
    };
    generateOtpCodesByIds = async (recordIds) => {
      if (!isActiveVaultInitialized) {
        throw new Error("Vault not initialised");
      }
      const results = [];
      for (const recordId of recordIds) {
        try {
          const record = await activeVaultGetRaw(`record/${recordId}`);
          if (!record?.data?.otp) continue;
          const otp = record.data.otp;
          if (otp.type === OTP_TYPE.TOTP) {
            const { code, timeRemaining } = generateTOTP(otp);
            results.push({ recordId, code, timeRemaining });
          } else if (otp.type === OTP_TYPE.HOTP) {
            const { code } = generateHOTP(otp);
            results.push({ recordId, code });
          }
        } catch (error) {
          workletLogger.error(
            `Failed to generate OTP code for record ${recordId}:`,
            error
          );
        }
      }
      return results;
    };
    generateHotpNext = async (recordId) => {
      if (!isActiveVaultInitialized) {
        throw new Error("Vault not initialised");
      }
      const record = await activeVaultGetRaw(`record/${recordId}`);
      if (!record) {
        throw new Error("Record not found");
      }
      if (!record.data?.otp || record.data.otp.type !== OTP_TYPE.HOTP) {
        throw new Error("Record does not have HOTP configuration");
      }
      const otp = record.data.otp;
      const newCounter = (otp.counter || 0) + 1;
      const { code } = generateHOTP({ ...otp, counter: newCounter });
      record.data.otp = { ...otp, counter: newCounter };
      await activeVaultAdd(`record/${recordId}`, record);
      return { code, counter: newCounter };
    };
    addOtpToRecord = async (recordId, otpInput) => {
      if (!isActiveVaultInitialized) {
        throw new Error("Vault not initialised");
      }
      const record = await activeVaultGetRaw(`record/${recordId}`);
      if (!record?.data) {
        throw new Error("Record not found");
      }
      const otpConfig = parseOtpInput(otpInput);
      record.data.otp = otpConfig;
      await activeVaultAdd(`record/${recordId}`, record);
    };
    removeOtpFromRecord = async (recordId) => {
      if (!isActiveVaultInitialized) {
        throw new Error("Vault not initialised");
      }
      const record = await activeVaultGetRaw(`record/${recordId}`);
      if (!record?.data) {
        throw new Error("Record not found");
      }
      delete record.data.otp;
      await activeVaultAdd(`record/${recordId}`, record);
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/decryptVaultKey.js
var import_sodium_native2, decryptVaultKey;
var init_decryptVaultKey = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/decryptVaultKey.js"() {
    import_sodium_native2 = __toESM(require("sodium-native"), 1);
    decryptVaultKey = (data) => {
      const ciphertext = Buffer.from(data.ciphertext, "base64");
      const nonce = Buffer.from(data.nonce, "base64");
      const hashedPassword = import_sodium_native2.default.sodium_malloc(import_sodium_native2.default.crypto_secretbox_KEYBYTES);
      const plainText = import_sodium_native2.default.sodium_malloc(
        ciphertext.length - import_sodium_native2.default.crypto_secretbox_MACBYTES
      );
      try {
        hashedPassword.write(data.hashedPassword, "hex");
        const opened = import_sodium_native2.default.crypto_secretbox_open_easy(
          plainText,
          ciphertext,
          nonce,
          hashedPassword
        );
        if (!opened) {
          return void 0;
        }
        return plainText.toString("base64");
      } finally {
        import_sodium_native2.default.sodium_memzero(hashedPassword);
        import_sodium_native2.default.sodium_memzero(plainText);
        import_sodium_native2.default.sodium_free(hashedPassword);
        import_sodium_native2.default.sodium_free(plainText);
      }
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/encryptVaultKeyWithHashedPassword.js
var import_sodium_native3, encryptVaultKeyWithHashedPassword;
var init_encryptVaultKeyWithHashedPassword = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/encryptVaultKeyWithHashedPassword.js"() {
    import_sodium_native3 = __toESM(require("sodium-native"), 1);
    encryptVaultKeyWithHashedPassword = (hashedPassword) => {
      const nonce = import_sodium_native3.default.sodium_malloc(import_sodium_native3.default.crypto_secretbox_NONCEBYTES);
      const key = import_sodium_native3.default.sodium_malloc(32);
      const ciphertext = import_sodium_native3.default.sodium_malloc(
        key.length + import_sodium_native3.default.crypto_secretbox_MACBYTES
      );
      const hashedPasswordBuf = import_sodium_native3.default.sodium_malloc(
        import_sodium_native3.default.crypto_secretbox_KEYBYTES
      );
      try {
        hashedPasswordBuf.write(hashedPassword, "hex");
        import_sodium_native3.default.randombytes_buf(key);
        import_sodium_native3.default.randombytes_buf(nonce);
        import_sodium_native3.default.crypto_secretbox_easy(ciphertext, key, nonce, hashedPasswordBuf);
        return {
          ciphertext: ciphertext.toString("base64"),
          nonce: nonce.toString("base64")
        };
      } finally {
        import_sodium_native3.default.sodium_memzero(nonce);
        import_sodium_native3.default.sodium_memzero(key);
        import_sodium_native3.default.sodium_memzero(ciphertext);
        import_sodium_native3.default.sodium_memzero(hashedPasswordBuf);
        import_sodium_native3.default.sodium_free(nonce);
        import_sodium_native3.default.sodium_free(key);
        import_sodium_native3.default.sodium_free(ciphertext);
        import_sodium_native3.default.sodium_free(hashedPasswordBuf);
      }
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/encryptVaultWithKey.js
var import_sodium_native4, encryptVaultWithKey;
var init_encryptVaultWithKey = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/encryptVaultWithKey.js"() {
    import_sodium_native4 = __toESM(require("sodium-native"), 1);
    encryptVaultWithKey = (hashedPassword, key) => {
      const nonce = import_sodium_native4.default.sodium_malloc(import_sodium_native4.default.crypto_secretbox_NONCEBYTES);
      const keyLen = Buffer.byteLength(key, "base64");
      const keyBuffer = import_sodium_native4.default.sodium_malloc(keyLen);
      const ciphertext = import_sodium_native4.default.sodium_malloc(
        keyLen + import_sodium_native4.default.crypto_secretbox_MACBYTES
      );
      const hashedPasswordBuf = import_sodium_native4.default.sodium_malloc(
        import_sodium_native4.default.crypto_secretbox_KEYBYTES
      );
      try {
        hashedPasswordBuf.write(hashedPassword, "hex");
        keyBuffer.write(key, "base64");
        import_sodium_native4.default.randombytes_buf(nonce);
        import_sodium_native4.default.crypto_secretbox_easy(
          ciphertext,
          keyBuffer,
          nonce,
          hashedPasswordBuf
        );
        return {
          ciphertext: ciphertext.toString("base64"),
          nonce: nonce.toString("base64")
        };
      } finally {
        import_sodium_native4.default.sodium_memzero(nonce);
        import_sodium_native4.default.sodium_memzero(keyBuffer);
        import_sodium_native4.default.sodium_memzero(ciphertext);
        import_sodium_native4.default.sodium_memzero(hashedPasswordBuf);
        import_sodium_native4.default.sodium_free(nonce);
        import_sodium_native4.default.sodium_free(keyBuffer);
        import_sodium_native4.default.sodium_free(ciphertext);
        import_sodium_native4.default.sodium_free(hashedPasswordBuf);
      }
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/getDecryptionKey.js
var import_sodium_native5, getDecryptionKey;
var init_getDecryptionKey = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/getDecryptionKey.js"() {
    import_sodium_native5 = __toESM(require("sodium-native"), 1);
    getDecryptionKey = (data) => {
      const salt = Buffer.from(data.salt, "base64");
      const passwordLen = Buffer.byteLength(data.password, "base64");
      const password = import_sodium_native5.default.sodium_malloc(passwordLen);
      const hashedPassword = import_sodium_native5.default.sodium_malloc(import_sodium_native5.default.crypto_secretbox_KEYBYTES);
      const opslimit = import_sodium_native5.default.crypto_pwhash_OPSLIMIT_SENSITIVE;
      const memlimit = import_sodium_native5.default.crypto_pwhash_MEMLIMIT_INTERACTIVE;
      const algo = import_sodium_native5.default.crypto_pwhash_ALG_DEFAULT;
      try {
        password.write(data.password, "base64");
        import_sodium_native5.default.crypto_pwhash(
          hashedPassword,
          password,
          salt,
          opslimit,
          memlimit,
          algo
        );
        return Buffer.from(hashedPassword).toString("hex");
      } finally {
        import_sodium_native5.default.sodium_memzero(password);
        import_sodium_native5.default.sodium_memzero(hashedPassword);
        import_sodium_native5.default.sodium_free(password);
        import_sodium_native5.default.sodium_free(hashedPassword);
      }
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/hashPassword.js
var import_sodium_native6, hashPassword;
var init_hashPassword = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/hashPassword.js"() {
    import_sodium_native6 = __toESM(require("sodium-native"), 1);
    hashPassword = (password) => {
      const passwordBuffer = Buffer.from(password, "base64");
      const salt = import_sodium_native6.default.sodium_malloc(import_sodium_native6.default.crypto_pwhash_SALTBYTES);
      const hashedPassword = import_sodium_native6.default.sodium_malloc(import_sodium_native6.default.crypto_secretbox_KEYBYTES);
      const opslimit = import_sodium_native6.default.crypto_pwhash_OPSLIMIT_SENSITIVE;
      const memlimit = import_sodium_native6.default.crypto_pwhash_MEMLIMIT_INTERACTIVE;
      const algo = import_sodium_native6.default.crypto_pwhash_ALG_DEFAULT;
      try {
        import_sodium_native6.default.randombytes_buf(salt);
        import_sodium_native6.default.crypto_pwhash(
          hashedPassword,
          passwordBuffer,
          salt,
          opslimit,
          memlimit,
          algo
        );
        return {
          hashedPassword: Buffer.from(hashedPassword).toString("hex"),
          salt: salt.toString("base64")
        };
      } finally {
        import_sodium_native6.default.sodium_memzero(hashedPassword);
        import_sodium_native6.default.sodium_memzero(salt);
        import_sodium_native6.default.sodium_memzero(passwordBuffer);
        import_sodium_native6.default.sodium_free(hashedPassword);
        import_sodium_native6.default.sodium_free(salt);
        import_sodium_native6.default.sodium_free(passwordBuffer);
      }
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/exportDataEncryption.js
var encryptExportData, decryptExportData;
var init_exportDataEncryption = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/exportDataEncryption.js"() {
    init_decryptVaultKey();
    init_encryptVaultWithKey();
    init_getDecryptionKey();
    init_hashPassword();
    encryptExportData = (data, password) => {
      const { hashedPassword, salt } = hashPassword(
        Buffer.from(password, "utf8").toString("base64")
      );
      const dataBuffer = Buffer.from(data, "utf8");
      const { ciphertext, nonce } = encryptVaultWithKey(
        hashedPassword,
        dataBuffer.toString("base64")
      );
      return {
        version: "1.0",
        encrypted: true,
        algorithm: "XSalsa20-Poly1305",
        kdf: "Argon2id",
        salt,
        nonce,
        ciphertext
      };
    };
    decryptExportData = (encryptedData, password) => {
      if (!encryptedData.encrypted) {
        throw new Error("Data is not encrypted");
      }
      const hashedPassword = getDecryptionKey({
        password: Buffer.from(password, "utf8").toString("base64"),
        salt: encryptedData.salt
      });
      const decryptedBase64 = decryptVaultKey({
        ciphertext: encryptedData.ciphertext,
        nonce: encryptedData.nonce,
        hashedPassword
      });
      if (!decryptedBase64) {
        throw new Error("Decryption failed - invalid password or corrupted data");
      }
      const decryptedData = Buffer.from(decryptedBase64, "base64").toString("utf8");
      return decryptedData;
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/utils/urlUtils.js
var addHttps;
var init_urlUtils = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/utils/urlUtils.js"() {
    addHttps = (url) => {
      const lowerUrl = url.toLowerCase();
      return lowerUrl.startsWith("http://") || lowerUrl.startsWith("https://") ? lowerUrl : `https://${lowerUrl}`;
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/faviconManager.js
var import_bare_fetch, getFromCache, saveToCache, faviconManager;
var init_faviconManager = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/faviconManager.js"() {
    import_bare_fetch = __toESM(require("bare-fetch"), 1);
    init_appDeps();
    init_urlUtils();
    init_workletLogger();
    getFromCache = async ({ hostname, cacheKey, isVaultReady }) => {
      if (!isVaultReady) return null;
      try {
        const cachedBuffer = await activeVaultGetFile(cacheKey);
        if (cachedBuffer) {
          workletLogger.log("Favicon cache hit:", hostname);
          const base64 = Buffer.from(cachedBuffer).toString("base64");
          return `data:image/png;base64,${base64}`;
        }
      } catch {
      }
      return null;
    };
    saveToCache = async ({ hostname, cacheKey, buffer, isVaultReady }) => {
      if (!isVaultReady) return;
      try {
        workletLogger.log("Storing favicon to cache:", hostname);
        await activeVaultAdd(
          cacheKey,
          { created_at: Date.now() },
          buffer,
          `${hostname}.png`
        );
      } catch (err) {
        workletLogger.warn("Failed to cache favicon:", err);
      }
    };
    faviconManager = {
      /**
       * Fetches a favicon for the given URL and returns it as a base64 data URI
       * @param {string} url - The domain URL to fetch favicon for
       * @returns {Promise<string|null>} Base64 data URI string or null if fetch fails
       */
      fetchFavicon: async (url) => {
        if (!url) return null;
        const targetUrl = addHttps(url);
        const hostname = new URL(targetUrl).hostname;
        const cacheKey = `favicon/${hostname}`;
        const isVaultReady = getIsActiveVaultInitialized();
        const cachedFavicon = await getFromCache({
          hostname,
          cacheKey,
          isVaultReady
        });
        if (cachedFavicon) {
          return cachedFavicon;
        }
        const faviconUrl = `https://www.google.com/s2/favicons?domain=${targetUrl}&sz=64`;
        try {
          const imgResponse = await (0, import_bare_fetch.default)(faviconUrl);
          workletLogger.log("Fetching favicon from network:", hostname);
          if (imgResponse.ok) {
            const arrayBuffer = await imgResponse.arrayBuffer();
            const buffer = Buffer.from(arrayBuffer);
            await saveToCache({ hostname, cacheKey, buffer, isVaultReady });
            const base64 = buffer.toString("base64");
            return `data:image/png;base64,${base64}`;
          }
        } catch (error) {
          workletLogger.warn("Failed to fetch favicon image:", error);
        }
        return null;
      }
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/masterPasswordManager.js
var import_pearpass_utils_password_check, MasterPasswordManager, masterPasswordManager;
var init_masterPasswordManager = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/masterPasswordManager.js"() {
    import_pearpass_utils_password_check = require("@tetherto/pearpass-utils-password-check");
    init_appDeps();
    init_decryptVaultKey();
    init_encryptVaultKeyWithHashedPassword();
    init_encryptVaultWithKey();
    init_getDecryptionKey();
    init_hashPassword();
    MasterPasswordManager = class {
      async ensureEncryptionInitialized() {
        if (!getIsEncryptionInitialized()) {
          await encryptionInit();
        }
      }
      async ensureVaultsInitialized({ encryptionKey, hashedPassword }) {
        if (!getIsVaultsInitialized()) {
          await masterVaultInit({ encryptionKey, hashedPassword });
        }
      }
      async getExistingMasterEncryption() {
        if (getIsVaultsInitialized()) {
          const masterEnc = await vaultsGet("masterEncryption");
          if (masterEnc) {
            return masterEnc;
          }
        }
        await this.ensureEncryptionInitialized();
        const enc = await encryptionGet("masterPassword");
        return enc;
      }
      async createMasterPassword({ passwordBase64 }) {
        if (!passwordBase64) {
          throw new Error("Password is required");
        }
        await this.ensureEncryptionInitialized();
        const existing = await encryptionGet("masterPassword");
        if (existing) {
          throw new Error("Master password already exists");
        }
        const { hashedPassword, salt } = hashPassword(passwordBase64);
        const { ciphertext, nonce } = encryptVaultKeyWithHashedPassword(hashedPassword);
        const decryptedKey = decryptVaultKey({
          ciphertext,
          nonce,
          hashedPassword
        });
        if (!decryptedKey) {
          throw new Error("Error decrypting vault key");
        }
        await this.ensureVaultsInitialized({
          encryptionKey: decryptedKey,
          hashedPassword
        });
        await vaultsAdd("masterEncryption", {
          ciphertext,
          nonce,
          salt,
          hashedPassword
        });
        await closeVaultsInstance();
        await encryptionAdd("masterPassword", {
          ciphertext,
          nonce,
          salt
        });
        return { hashedPassword, salt, ciphertext, nonce };
      }
      async initWithPassword({ passwordBase64 }) {
        if (!passwordBase64) {
          throw new Error("Password is required");
        }
        if (getIsVaultsInitialized()) {
          const masterEncryption = await vaultsGet("masterEncryption");
          if (!masterEncryption) {
            throw new Error("Master encryption not found");
          }
          const derived = getDecryptionKey({
            salt: masterEncryption.salt,
            password: passwordBase64
          });
          if (!(0, import_pearpass_utils_password_check.constantTimeHashCompare)(masterEncryption.hashedPassword, derived)) {
            throw new Error(
              "Provided credentials do not match existing master encryption"
            );
          }
          return { success: true };
        }
        await this.ensureEncryptionInitialized();
        const encryptionGetRes = await encryptionGet("masterPassword");
        if (!encryptionGetRes) {
          throw new Error("Master password not set");
        }
        const { ciphertext, nonce, salt } = encryptionGetRes;
        const hashedPassword = getDecryptionKey({
          salt,
          password: passwordBase64
        });
        const decryptVaultKeyRes = decryptVaultKey({
          ciphertext,
          nonce,
          hashedPassword
        });
        if (!decryptVaultKeyRes) {
          await rateLimitRecordFailure();
          throw new Error("Error decrypting vault key");
        }
        await masterVaultInit({
          encryptionKey: decryptVaultKeyRes,
          hashedPassword
        });
        return { success: true };
      }
      async updateMasterPassword({ newPassword, currentPassword }) {
        if (!newPassword || !currentPassword) {
          throw new Error("New and current passwords are required");
        }
        await this.ensureEncryptionInitialized();
        const masterEncryption = await this.getExistingMasterEncryption();
        if (!masterEncryption) {
          throw new Error("Master password not found");
        }
        const {
          ciphertext: currentCiphertext,
          nonce: currentNonce,
          salt: currentSalt,
          hashedPassword: currentHashedPassword
        } = masterEncryption;
        const derivedCurrent = getDecryptionKey({
          salt: currentSalt,
          password: currentPassword
        });
        if (currentHashedPassword && !(0, import_pearpass_utils_password_check.constantTimeHashCompare)(currentHashedPassword, derivedCurrent)) {
          throw new Error("Invalid password");
        }
        const currentVaultKey = decryptVaultKey({
          ciphertext: currentCiphertext,
          nonce: currentNonce,
          hashedPassword: currentHashedPassword || derivedCurrent
        });
        if (!currentVaultKey) {
          throw new Error("Error decrypting vault key");
        }
        const { hashedPassword: newHashedPassword, salt: newSalt } = hashPassword(newPassword);
        const { ciphertext, nonce } = encryptVaultWithKey(
          newHashedPassword,
          currentVaultKey
        );
        const verifyKey = decryptVaultKey({
          ciphertext,
          nonce,
          hashedPassword: newHashedPassword
        });
        if (!(0, import_pearpass_utils_password_check.constantTimeHashCompare)(verifyKey, currentVaultKey, "base64")) {
          throw new Error("Failed to verify new password encryption");
        }
        const activeVault = await activeVaultGet("vault");
        const activeVaultId = activeVault?.id;
        await closeVaultsInstance();
        await masterVaultInitWithNewBlindEncryption({
          encryptionKey: currentVaultKey,
          newHashedPassword,
          currentHashedPassword
        });
        await vaultsAdd("masterEncryption", {
          ciphertext,
          nonce,
          salt: newSalt,
          hashedPassword: newHashedPassword
        });
        await encryptionAdd("masterPassword", {
          ciphertext,
          nonce,
          salt: newSalt
        });
        await this.updateAllVaultsBlindEncryption({
          currentHashedPassword,
          newHashedPassword,
          activeVaultId,
          masterEncryptionKey: currentVaultKey
        });
        return {
          hashedPassword: newHashedPassword,
          salt: newSalt,
          ciphertext,
          nonce
        };
      }
      async initWithCredentials({ ciphertext, nonce, hashedPassword }) {
        if (!ciphertext || !nonce || !hashedPassword) {
          throw new Error("Missing required parameters");
        }
        await this.ensureEncryptionInitialized();
        const decryptVaultKeyRes = decryptVaultKey({
          ciphertext,
          nonce,
          hashedPassword
        });
        if (!decryptVaultKeyRes) {
          throw new Error("Error decrypting vault key");
        }
        await masterVaultInit({
          encryptionKey: decryptVaultKeyRes,
          hashedPassword
        });
        return { success: true };
      }
      async updateAllVaultsBlindEncryption({
        currentHashedPassword,
        newHashedPassword,
        activeVaultId,
        masterEncryptionKey
      }) {
        if (getIsActiveVaultInitialized()) {
          await closeActiveVaultInstance();
        }
        const allVaults = await vaultsList("vault/");
        for (const vault of allVaults) {
          if (!vault?.id) {
            continue;
          }
          const vaultInstance = await initInstanceWithNewBlindEncryption({
            path: `vault/${vault.id}`,
            encryptionKey: masterEncryptionKey,
            newHashedPassword,
            currentHashedPassword
          });
          await vaultInstance.close();
        }
        if (activeVaultId && masterEncryptionKey) {
          await initActiveVaultInstance({
            id: activeVaultId,
            encryptionKey: masterEncryptionKey
          });
        }
        return { success: true };
      }
    };
    masterPasswordManager = new MasterPasswordManager();
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/utils/dht.js
var import_hyperdht, sharedDHT, getSharedDHT, destroySharedDHT;
var init_dht = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/utils/dht.js"() {
    import_hyperdht = __toESM(require("hyperdht"), 1);
    sharedDHT = null;
    getSharedDHT = () => {
      if (!sharedDHT) {
        sharedDHT = new import_hyperdht.default();
      }
      return sharedDHT;
    };
    destroySharedDHT = async () => {
      if (sharedDHT) {
        try {
          await sharedDHT.destroy();
        } catch {
        }
        sharedDHT = null;
      }
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/middleware/validateMirrorKeyViaDHT.js
var import_hypercore_id_encoding, validateMirrorKeyViaDHT, filterReachableMirrors, withMirrorValidation;
var init_validateMirrorKeyViaDHT = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/middleware/validateMirrorKeyViaDHT.js"() {
    import_hypercore_id_encoding = __toESM(require("hypercore-id-encoding"), 1);
    init_dht();
    validateMirrorKeyViaDHT = async (key, options = {}) => {
      const { timeoutMs = 5e3 } = options;
      let decodedKey;
      try {
        decodedKey = import_hypercore_id_encoding.default.decode(key);
      } catch {
        return false;
      }
      const dht = getSharedDHT();
      return new Promise((resolve) => {
        const socket = dht.connect(decodedKey);
        let resolved = false;
        const resolveOnce = (success) => {
          if (resolved) return;
          resolved = true;
          try {
            socket.removeAllListeners();
            socket.destroy();
          } catch {
          }
          clearTimeout(timer);
          resolve(success);
        };
        const timer = setTimeout(() => resolveOnce(false), timeoutMs);
        socket.once("error", () => resolveOnce(false));
        socket.once("close", () => resolveOnce(false));
        socket.once("open", () => resolveOnce(true));
      });
    };
    filterReachableMirrors = async (mirrors, options = {}) => {
      if (!Array.isArray(mirrors) || mirrors.length === 0) return [];
      const checks = await Promise.all(
        mirrors.map(async (key) => ({
          key,
          ok: await validateMirrorKeyViaDHT(key, options)
        }))
      );
      return checks.filter((c) => c.ok).map((c) => c.key);
    };
    withMirrorValidation = (action, options = {}) => async (mirrors) => {
      const valid = await filterReachableMirrors(mirrors, options);
      if (valid.length === 0) {
        throw new Error("No reachable mirrors");
      }
      return action(valid);
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/utils/recieveFileStream.js
var import_buffer, import_compact_encoding, receiveFileStream;
var init_recieveFileStream = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/utils/recieveFileStream.js"() {
    import_buffer = require("buffer");
    import_compact_encoding = __toESM(require("compact-encoding"), 1);
    receiveFileStream = async (stream) => new Promise((resolve, reject) => {
      let metaData = null;
      let chunks = import_buffer.Buffer.from([]);
      stream.on("data", (data) => {
        if (!metaData) {
          const decodedMetadata = import_compact_encoding.default.decode(import_compact_encoding.default.json, data);
          metaData = decodedMetadata;
          return;
        }
        chunks = import_buffer.Buffer.concat([chunks, data]);
      });
      stream.on("end", () => {
        resolve({
          buffer: chunks,
          metaData
        });
      });
      stream.on("error", (error) => {
        reject(error);
      });
    });
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/utils/sendFileStream.js
var import_compact_encoding2, sendFileStream;
var init_sendFileStream = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/utils/sendFileStream.js"() {
    import_compact_encoding2 = __toESM(require("compact-encoding"), 1);
    sendFileStream = ({
      stream,
      buffer,
      start = 0,
      step = 8192,
      metaData = {}
    }) => {
      let chunk;
      if (!stream || !stream.write) {
        throw new Error("Invalid stream provided. Ensure it is a writable stream.");
      }
      if (!buffer) {
        stream.end();
        return;
      }
      if (start === 0) {
        stream.write(import_compact_encoding2.default.encode(import_compact_encoding2.default.json, metaData));
      }
      do {
        chunk = buffer?.subarray(start, start + step);
        if (!chunk?.length) {
          return stream.end();
        }
        start += step;
      } while (stream.write(chunk));
      stream.once("drain", () => sendFileStream({ stream, buffer, start, step }));
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/utils/isPearWorker.js
var isPearWorker;
var init_isPearWorker = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/utils/isPearWorker.js"() {
    isPearWorker = () => typeof Pear !== "undefined";
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/utils/parseRequestData.js
var parseRequestData;
var init_parseRequestData = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/utils/parseRequestData.js"() {
    parseRequestData = (data) => {
      if (!data) {
        return null;
      }
      try {
        return JSON.parse(data);
      } catch (_error) {
        return data;
      }
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/utils/logger.js
var Logger, logger;
var init_logger = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/utils/logger.js"() {
    Logger = class {
      constructor({ debugMode }) {
        this.debugMode = debugMode || false;
      }
      log(...messages) {
        if (!this.debugMode) {
          return;
        }
        console.log(messages);
      }
      error(...messages) {
        console.error(messages);
      }
    };
    logger = new Logger({
      debugMode: false
    });
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/utils/validateInviteCode.js
var import_pear_apps_utils_validator, INVITE_CODE_REGEX, INVITE_CODE_MIN_LENGTH, inviteCodeSchema, validateInviteCode;
var init_validateInviteCode = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/utils/validateInviteCode.js"() {
    import_pear_apps_utils_validator = require("@tetherto/pear-apps-utils-validator");
    init_logger();
    INVITE_CODE_REGEX = /^[a-zA-Z0-9-]+\/[a-zA-Z0-9-]+$/;
    INVITE_CODE_MIN_LENGTH = 100;
    inviteCodeSchema = import_pear_apps_utils_validator.Validator.object({
      code: import_pear_apps_utils_validator.Validator.string().refine((value) => {
        const isValid = value.length >= INVITE_CODE_MIN_LENGTH && INVITE_CODE_REGEX.test(value);
        if (!isValid) {
          return "Invalid invite code format";
        }
        return null;
      })
    });
    validateInviteCode = (code) => {
      const errors = inviteCodeSchema.validate({
        code
      });
      if (errors) {
        logger.error(`Invalid invite code: ${JSON.stringify(errors, null, 2)}`);
        throw new Error(`Invalid invite code: ${JSON.stringify(errors, null, 2)}`);
      }
      return code;
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/appCore.js
var appCore_exports = {};
__export(appCore_exports, {
  createRPC: () => createRPC,
  handleRpcCommand: () => handleRpcCommand,
  setupIPC: () => setupIPC
});
var import_bare_rpc, import_framed_stream, rpc, handleRpcCommand, setupIPC, createRPC;
var init_appCore = __esm({
  "node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/appCore.js"() {
    import_bare_rpc = __toESM(require("bare-rpc"), 1);
    import_framed_stream = __toESM(require("framed-stream"), 1);
    init_api();
    init_appDeps();
    init_decryptVaultKey();
    init_encryptVaultKeyWithHashedPassword();
    init_encryptVaultWithKey();
    init_exportDataEncryption();
    init_faviconManager();
    init_getDecryptionKey();
    init_hashPassword();
    init_masterPasswordManager();
    init_validateMirrorKeyViaDHT();
    init_dht();
    init_recieveFileStream();
    init_sendFileStream();
    init_isPearWorker();
    init_parseRequestData();
    init_workletLogger();
    init_validateInviteCode();
    rpc = null;
    handleRpcCommand = async (req) => {
      const commandName = API_BY_VALUE[req.command];
      const requestData = parseRequestData(req.data);
      workletLogger.log(`Received command: ${commandName}`, requestData ?? "");
      switch (req.command) {
        case API.STORAGE_PATH_SET:
          try {
            void setStoragePath(requestData?.path);
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error setting storage path: ${error}`
              })
            );
          }
          break;
        case API.SET_CORE_STORE_OPTIONS:
          try {
            workletLogger.log("Setting core store options:", requestData);
            setCoreStoreOptions(requestData?.coreStoreOptions);
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error setting core store options: ${error}`
              })
            );
          }
          break;
        case API.FETCH_FAVICON:
          try {
            const faviconBase64 = await faviconManager.fetchFavicon(
              requestData?.url
            );
            if (!faviconBase64) {
              throw new Error("Favicon not found");
            }
            req.reply(
              JSON.stringify({
                success: true,
                data: {
                  url: requestData?.url,
                  favicon: faviconBase64
                }
              })
            );
          } catch (err) {
            workletLogger.error("Error fetching favicon:", err);
            req.reply(
              JSON.stringify({
                success: false,
                error: err.toString()
              })
            );
          }
          break;
        case API.MASTER_VAULT_INIT:
          try {
            if (!requestData.encryptionKey) {
              throw new Error("Password is required");
            }
            const res = await masterVaultInit({
              encryptionKey: requestData.encryptionKey,
              hashedPassword: requestData.hashedPassword
            });
            req.reply(JSON.stringify({ success: true, res }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error initializing vaults: ${error}`
              })
            );
          }
          break;
        case API.MASTER_VAULT_GET_STATUS:
          req.reply(JSON.stringify({ data: { status: getIsVaultsInitialized() } }));
          break;
        case API.MASTER_VAULT_GET:
          try {
            const res = await vaultsGet(requestData?.key);
            req.reply(JSON.stringify({ data: res }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error getting records from active vault: ${error}`
              })
            );
          }
          break;
        case API.MASTER_VAULT_CLOSE:
          try {
            await closeVaultsInstance();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error closing vaults: ${error}`
              })
            );
          }
          break;
        case API.MASTER_VAULT_ADD:
          try {
            await vaultsAdd(requestData?.key, requestData?.data);
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error adding vault: ${error}`
              })
            );
          }
          break;
        case API.ACTIVE_VAULT_FILE_ADD:
          try {
            const stream = req.createRequestStream();
            const { buffer, metaData } = await receiveFileStream(stream);
            const { key, name } = metaData ?? {};
            await activeVaultAdd(key, {}, buffer, name);
            workletLogger.log({
              stream: `Received stream data of size: ${buffer.length}`,
              data: JSON.stringify(metaData)
            });
            req.reply(JSON.stringify({ success: true, metaData }));
          } catch (error) {
            workletLogger.error("Error adding file to active vault:", error);
            req.reply(
              JSON.stringify({
                error: `Could not add ${error.details?.fileName ?? "file"} to the active vault: ${error.message}`
              })
            );
          }
          break;
        case API.ACTIVE_VAULT_FILE_GET:
          try {
            const file = await activeVaultGetFile(requestData?.key);
            const stream = req.createResponseStream();
            sendFileStream({
              stream,
              buffer: file,
              metaData: { key: requestData?.key }
            });
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error getting file from active vault: ${error}`
              })
            );
          }
          break;
        case API.ACTIVE_VAULT_FILE_REMOVE:
          try {
            await activeVaultRemoveFile(requestData?.key);
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error removing file from active vault: ${error}`
              })
            );
          }
          break;
        case API.MASTER_VAULT_LIST:
          try {
            const vaults = await vaultsList(requestData?.filterKey);
            req.reply(JSON.stringify({ data: vaults }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error listing vaults: ${error}`
              })
            );
          }
          break;
        case API.ACTIVE_VAULT_INIT:
          try {
            await initActiveVaultInstance({
              id: requestData?.id,
              encryptionKey: requestData?.encryptionKey
            });
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error initializing active vault: ${error}`
              })
            );
          }
          break;
        case API.ACTIVE_VAULT_GET_STATUS:
          req.reply(
            JSON.stringify({ data: { status: getIsActiveVaultInitialized() } })
          );
          break;
        case API.ACTIVE_VAULT_CLOSE:
          try {
            await closeActiveVaultInstance();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error closing active vault: ${error}`
              })
            );
          }
          break;
        case API.ACTIVE_VAULT_ADD:
          try {
            await activeVaultAdd(requestData?.key, requestData?.data);
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error adding record to active vault: ${error}`
              })
            );
          }
          break;
        case API.ACTIVE_VAULT_REMOVE:
          try {
            await vaultRemove(requestData?.key);
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error removing record from active vault: ${error}`
              })
            );
          }
          break;
        case API.ACTIVE_VAULT_LIST:
          try {
            const listResults = await activeVaultList(requestData?.filterKey);
            req.reply(JSON.stringify({ data: listResults }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error listing records from active vault: ${error}`
              })
            );
          }
          break;
        case API.ACTIVE_VAULT_GET:
          try {
            const record = await activeVaultGet(requestData?.key);
            req.reply(JSON.stringify({ data: record }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error getting records from active vault: ${error}`
              })
            );
          }
          break;
        case API.ACTIVE_VAULT_CREATE_INVITE:
          try {
            const invite = await createInvite();
            req.reply(JSON.stringify({ data: invite }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error creating invite from active vault: ${error}`
              })
            );
          }
          break;
        case API.ACTIVE_VAULT_DELETE_INVITE:
          try {
            await deleteInvite();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error deleting invite from active vault: ${error}`
              })
            );
          }
          break;
        case API.PAIR_ACTIVE_VAULT:
          try {
            workletLogger.log("Validating invite code:", requestData.inviteCode);
            validateInviteCode(requestData.inviteCode);
            workletLogger.log("Pairing with invite code:", requestData.inviteCode);
            const { vaultId, encryptionKey } = await pairActiveVault(
              requestData.inviteCode
            );
            req.reply(JSON.stringify({ data: { vaultId, encryptionKey } }));
            workletLogger.log(
              "Pairing successful with invite code:",
              requestData.inviteCode,
              "Vault ID:",
              vaultId,
              "Encryption Key:",
              encryptionKey
            );
          } catch (error) {
            workletLogger.error("Error pairing with invite code:", error);
            req.reply(
              JSON.stringify({
                error: `Error pairing with invite code: ${error}`
              })
            );
          }
          break;
        case API.CANCEL_PAIR_ACTIVE_VAULT:
          try {
            workletLogger.log("Canceling pairing with active vault");
            await cancelPairActiveVault();
            req.reply(JSON.stringify({ success: true }));
            workletLogger.log("Pairing with active vault canceled successfully");
          } catch (error) {
            workletLogger.error("Error canceling pairing with active vault:", error);
            req.reply(
              JSON.stringify({
                error: `Error canceling pairing with active vault: ${error}`
              })
            );
          }
          break;
        case API.MASTER_PASSWORD_STATUS:
          const result = await getRateLimitStatus();
          req.reply(JSON.stringify({ data: result }));
          break;
        case API.RECORD_FAILED_MASTER_PASSWORD:
          try {
            await rateLimitRecordFailure();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error recording failed master pass: ${error}`
              })
            );
          }
          break;
        case API.RESET_FAILED_ATTEMPTS:
          try {
            await resetRateLimit();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error resetting failed attempts: ${error}`
              })
            );
          }
          break;
        case API.MASTER_PASSWORD_CREATE:
          try {
            const data = await masterPasswordManager.createMasterPassword({
              passwordBase64: requestData.password
            });
            req.reply(JSON.stringify({ data }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error creating master password: ${error}`
              })
            );
          }
          break;
        case API.MASTER_PASSWORD_INIT_WITH_PASSWORD:
          try {
            const data = await masterPasswordManager.initWithPassword({
              passwordBase64: requestData.password
            });
            req.reply(JSON.stringify({ data }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error initializing with password: ${error}`
              })
            );
          }
          break;
        case API.MASTER_PASSWORD_UPDATE:
          try {
            const data = await masterPasswordManager.updateMasterPassword({
              newPassword: requestData.newPassword,
              currentPassword: requestData.currentPassword
            });
            req.reply(JSON.stringify({ data }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error updating master password: ${error}`
              })
            );
          }
          break;
        case API.MASTER_PASSWORD_INIT_WITH_CREDENTIALS:
          try {
            const data = await masterPasswordManager.initWithCredentials({
              ciphertext: requestData.ciphertext,
              nonce: requestData.nonce,
              hashedPassword: requestData.hashedPassword
            });
            req.reply(JSON.stringify({ data }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error initializing with credentials: ${error}`
              })
            );
          }
          break;
        case API.INIT_LISTENER:
          try {
            if (!getIsActiveVaultInitialized()) {
              throw new Error("Active vault not initialized");
            }
            const vaultId = requestData.vaultId;
            await initListener({
              vaultId,
              onUpdate: () => {
                const req2 = rpc.request(API.ON_UPDATE);
                req2.send();
              }
            });
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error initializing listener: ${error}`
              })
            );
          }
          break;
        case API.ENCRYPTION_INIT:
          try {
            await encryptionInit();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error initializing encryption: ${error}`
              })
            );
          }
          break;
        case API.ENCRYPTION_GET_STATUS:
          req.reply(
            JSON.stringify({ data: { status: getIsEncryptionInitialized() } })
          );
          break;
        case API.ENCRYPTION_GET:
          try {
            const res = await encryptionGet(requestData?.key);
            req.reply(JSON.stringify({ data: res }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error getting encryption data: ${error}`
              })
            );
          }
          break;
        case API.ENCRYPTION_ADD:
          try {
            await encryptionAdd(requestData?.key, requestData?.data);
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error adding encryption data: ${error}`
              })
            );
          }
          break;
        case API.ENCRYPTION_HASH_PASSWORD:
          try {
            const res = hashPassword(requestData.password);
            req.reply(JSON.stringify({ data: res }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error hashPassword: ${error}`
              })
            );
          }
          break;
        case API.ENCRYPTION_ENCRYPT_VAULT_KEY_WITH_HASHED_PASSWORD:
          try {
            const res = encryptVaultKeyWithHashedPassword(
              requestData.hashedPassword
            );
            req.reply(JSON.stringify({ data: res }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error encryptVaultKeyWithHashedPassword: ${error}`
              })
            );
          }
          break;
        case API.ENCRYPTION_ENCRYPT_VAULT_WITH_KEY:
          try {
            const res = encryptVaultWithKey(
              requestData.hashedPassword,
              requestData.key
            );
            req.reply(JSON.stringify({ data: res }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error encryptVaultWithKey: ${error}`
              })
            );
          }
          break;
        case API.ENCRYPTION_GET_DECRYPTION_KEY:
          try {
            const { salt, password } = requestData;
            const hashedPassword = getDecryptionKey({
              password,
              salt
            });
            req.reply(JSON.stringify({ data: hashedPassword }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error getDecryptionKey: ${error}`
              })
            );
          }
          break;
        case API.ENCRYPTION_DECRYPT_VAULT_KEY:
          try {
            const { ciphertext, nonce, hashedPassword } = requestData;
            const res = decryptVaultKey({
              ciphertext,
              nonce,
              hashedPassword
            });
            req.reply(JSON.stringify({ data: res }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error decrypting vault key: ${error}`
              })
            );
          }
          break;
        case API.ENCRYPTION_ENCRYPT_EXPORT_DATA:
          try {
            const { data, password } = requestData;
            const encryptedData = encryptExportData(data, password);
            req.reply(JSON.stringify({ data: encryptedData }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error encrypting export data: ${error}`
              })
            );
          }
          break;
        case API.ENCRYPTION_DECRYPT_EXPORT_DATA:
          try {
            const { encryptedData, password } = requestData;
            const decryptedData = decryptExportData(encryptedData, password);
            req.reply(JSON.stringify({ data: decryptedData }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error decrypting export data: ${error.message || error}`
              })
            );
          }
          break;
        case API.ENCRYPTION_CLOSE:
          try {
            await encryptionClose();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error closing encryption: ${error}`
              })
            );
          }
          break;
        case API.CLOSE_ALL_INSTANCES:
          try {
            await closeAllInstances();
            await destroySharedDHT();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error closing encryption: ${error}`
              })
            );
          }
          break;
        case API.BLIND_MIRRORS_GET:
          try {
            const mirrors = await getBlindMirrors();
            req.reply(JSON.stringify({ data: mirrors }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error getting blind mirrors: ${error}`
              })
            );
          }
          break;
        case API.BLIND_MIRRORS_ADD:
          try {
            const safeAdd = withMirrorValidation(addBlindMirrors);
            await safeAdd(requestData?.blindMirrors || []);
            await restartActiveVault();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error adding blind mirrors: ${error}`
              })
            );
          }
          break;
        case API.BLIND_MIRROR_REMOVE:
          try {
            await removeBlindMirror(requestData?.key);
            await restartActiveVault();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error removing blind mirrors: ${error}`
              })
            );
          }
          break;
        case API.BLIND_MIRRORS_ADD_DEFAULTS:
          try {
            await addDefaultBlindMirrors();
            await restartActiveVault();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error adding default blind mirrors: ${error}`
              })
            );
          }
          break;
        case API.BLIND_MIRRORS_REMOVE_ALL:
          try {
            await removeAllBlindMirrors();
            await restartActiveVault();
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error removing all blind mirrors: ${error}`
              })
            );
          }
          break;
        case API.SET_JOB_STORAGE_PATH:
          try {
            setJobStoragePath(requestData?.path);
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error setting job storage path: ${error}`
              })
            );
          }
          break;
        case API.READ_JOB_QUEUE:
          try {
            const jobs = await readAndDecryptJobFile();
            req.reply(JSON.stringify({ data: jobs }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error reading job queue: ${error}`
              })
            );
          }
          break;
        case API.WRITE_JOB_QUEUE:
          try {
            await writeAndEncryptJobFile(requestData?.jobs);
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error writing job queue: ${error}`
              })
            );
          }
          break;
        case API.GENERATE_OTP_CODES_BY_IDS:
          try {
            const otpCodes = await generateOtpCodesByIds(requestData?.recordIds);
            req.reply(JSON.stringify({ data: otpCodes }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error generating OTP codes: ${error}`
              })
            );
          }
          break;
        case API.GENERATE_HOTP_NEXT:
          try {
            const hotpResult = await generateHotpNext(requestData?.recordId);
            req.reply(JSON.stringify({ data: hotpResult }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error generating next HOTP code: ${error}`
              })
            );
          }
          break;
        case API.ADD_OTP_TO_RECORD:
          try {
            await addOtpToRecord(requestData?.recordId, requestData?.otpInput);
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error adding OTP to record: ${error}`
              })
            );
          }
          break;
        case API.REMOVE_OTP_FROM_RECORD:
          try {
            await removeOtpFromRecord(requestData?.recordId);
            req.reply(JSON.stringify({ success: true }));
          } catch (error) {
            req.reply(
              JSON.stringify({
                error: `Error removing OTP from record: ${error}`
              })
            );
          }
          break;
        default:
          req.reply(
            JSON.stringify({
              error: `Unknown command: ${req.command}`
            })
          );
          return;
      }
    };
    setupIPC = () => {
      const ipc = isPearWorker() ? Pear.worker.pipe() : (
        // New bare-sidecar exposes IPC on Bare.IPC.
        // eslint-disable-next-line no-undef
        typeof Bare !== "undefined" && Bare?.IPC || // Older pear-sidecar builds exposed IPC via BareKit.IPC.
        typeof BareKit !== "undefined" && BareKit?.IPC || // Legacy sidecar runtime set global symbol.
        global[Symbol.for("bare.sidecar.ipc")]
      );
      if (!ipc) {
        throw new Error(
          "Worklet IPC not available (not Pear worker and no bare.sidecar.ipc)"
        );
      }
      if (typeof ipc.ref === "function") {
        ipc.ref();
      }
      ipc.on("close", async () => {
        await destroySharedDHT();
        Bare.exit(0);
      });
      ipc.on("end", async () => {
        await destroySharedDHT();
        Bare.exit(0);
      });
      if (typeof Bare !== "undefined") {
        workletLogger.log("Bare lifecycle events detected");
        Bare.on("suspend", () => {
          workletLogger.log("Bare suspend event detected");
          suspendAllInstances().catch(() => workletLogger.error("Error suspending instances")).then(() => workletLogger.log("Instances suspended successfully"));
        });
        Bare.on("resume", () => {
          workletLogger.log("Bare resume event detected");
          resumeAllInstances().catch(() => workletLogger.error("Error resuming instances")).then(() => workletLogger.log("Instances resumed successfully"));
        });
      }
      return ipc;
    };
    createRPC = (ipc) => {
      rpc = new import_bare_rpc.default(new import_framed_stream.default(ipc), (req) => {
        try {
          return handleRpcCommand(req);
        } catch (error) {
          req.reply(
            JSON.stringify({
              error: `Unexpected error: ${error}`
            })
          );
        }
      });
      return rpc;
    };
  }
});

// node_modules/@tetherto/pearpass-lib-vault-core/src/worklet/app.js
var app_exports = {};
__export(app_exports, {
  rpc: () => rpc2
});
module.exports = __toCommonJS(app_exports);
init_workletLogger();
var rpc2;
(async () => {
  try {
    const { setupIPC: setupIPC2, createRPC: createRPC2 } = await Promise.resolve().then(() => (init_appCore(), appCore_exports));
    const ipc = setupIPC2();
    rpc2 = createRPC2(ipc);
  } catch (error) {
    workletLogger.error("Fatal error in app initialization:", error);
  }
})();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  rpc
});
